#include "FileCopy.h"

using namespace DesktopTrack;

FileCopy::FileCopy(QObject* parent):
    QThread(parent){}

bool FileCopy::setFiles(
        const QStringList &origFiles,
        const QStringList &destFiles)
{
    if(origFiles.size()!=destFiles.size()){
        return false;
    }
    if(isRunning()){
        return false;
    }
    else{
        this->origFiles=origFiles;
        this->destFiles=destFiles;
        return true;
    }
}

void FileCopy::setProcessStatus(
        const Process& process_status,
        const quint64& prosessed_data,
        const quint64& total_data)
{
    mutex.lock();
    processStatus = process_status;
    processedData = prosessed_data;
    totalData = total_data;
    mutex.unlock();
}

bool FileCopy::getOrder(void)
{
    mutex.lock();
    bool order = promoteProcess;
    mutex.unlock();
    return order;
}

void FileCopy::setOrder(
        bool proceed)
{
    mutex.lock();
    promoteProcess = proceed;
    mutex.unlock();
}

void FileCopy::getProcessStatus(
        Process& process_status,
        quint64& prosessed_data,
        quint64& total_data)
{
    mutex.lock();
    process_status = processStatus;
    prosessed_data = processedData;
    total_data = totalData;
    mutex.unlock();
}

void FileCopy::run(void){

    int numOfFiles=origFiles.size();
    setProcessStatus(processing, 0, numOfFiles*100);

    for(int i=0; i<numOfFiles; i++){

        QFileInfo info(origFiles[i]);
        if(!info.exists()){
            return;
        }
        qint64 fileSize = info.size();
        qint64 processed = 0;

        QFile in(origFiles[i]);
        if(!in.open(QIODevice::ReadOnly)){
            return;
        }
        QFile out(destFiles[i]);
        if(!out.open(QIODevice::WriteOnly)){
            return;
        }
        QByteArray buffer;
        int counter=0;
        while(!in.atEnd()){
            buffer = in.read(BufferSizeMax);
            if(buffer.size()==0){
                break;
            }
            out.write(buffer);
            processed+=buffer.size();
            counter++;
            if(counter%1000==0){
				//��~���߂��o���ꍇ�́A�����𒆎~���A����܂ŃR�s�[�����t�@�C�����폜����
                if(!getOrder()){
                    setProcessStatus(stopped, processed*100/fileSize+i*100, numOfFiles*100);
					in.close();
					out.close();
					for (int j = 0; j<=i; j++) {
						QFile file(destFiles[j]);
						file.remove();
					}
                    return;
                }
                setProcessStatus(processing, processed*100/fileSize+i*100, numOfFiles*100);
            }
        }
    }
    setProcessStatus(finished, 100, 100);
}














