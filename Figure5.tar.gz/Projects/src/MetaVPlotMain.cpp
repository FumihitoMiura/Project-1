#include <QtCore>
#include <QtGui>
#include <vector>
#include <cstdlib>

#include "DesktopTrackCommon.h"
#include "BinSeq.h"
#include "VPlotFile.h"

#include "qcustomplot/qcustomplot.h"

using namespace DesktopTrack;

void showUsage(void) {
	cout << "Usage : MetaVPlot [options]" << endl
		<< "  [Required Parameters]" << endl
		<< "   -vplot        [string]  : input vplot file name" << endl
		<< "   -gff3         [string]  : input gff3 file name" << endl
		<< "   -out          [string]  : output file name" << endl
		<< "   -png          [string]  : output png file" << endl
		<< "   -pdf          [string]  : output pdf file" << endl
		<< "   -up           [integer] : positive integer value, should be larger than 10." << endl
		<< "   -down         [integer] : positive integer value, should be larger than 10." << endl
		<< "   -yscale       [integer] : maximum value for y-axis, positive integer value." << endl
		<< "   -feature      [string]  : feature type." << endl;
}

const QRegExp GFF3Pragma("##gff-version[\\s]+3");
const QRegExp FastaStart("##FASTA");

QString vplotPath;
QString gff3Path;
QString outPath;
QString pngPath;
QString pdfPath;
quint64 upSize = 500;
quint64 downSize = 500;
QSet<QString> featureSet;
bool yscale = false;
qreal yscale_max = 0;


bool ProcessArguments(int argc, char* argv[]) {

	int i = 1;
	while (i<argc) {
		QString option(argv[i]);
		if (option == QString("-vplot")) {
			i++;
			if (i == argc) {
				break;
			}
			vplotPath = argv[i];
		}
		else if (option == QString("-gff3")) {
			i++;
			if (i == argc) {
				break;
			}
			gff3Path = argv[i];
		}
		else if (option == QString("-out")) {
			i++;
			if (i == argc) {
				break;
			}
			outPath = argv[i];
		}
		else if (option == QString("-png")) {
			i++;
			if (i == argc) {
				break;
			}
			pngPath = argv[i];
		}
		else if (option == QString("-pdf")) {
			i++;
			if (i == argc) {
				break;
			}
			pdfPath = argv[i];
		}
		else if (option == QString("-up")) {
			i++;
			if (i == argc) {
				break;
			}
			quint64 temp = QString(argv[i]).toUInt();
			if (temp <= 10) {
				cerr << "Minimum upstream size should be larger than 10" << endl;
				return false;
			}
			upSize = temp;
		}
		else if (option == QString("-down")) {
			i++;
			if (i == argc) {
				break;
			}
			quint64 temp = QString(argv[i]).toUInt();
			if (temp <= 10) {
				cerr << "Minimum downstream size should be larger than 10" << endl;
				return false;
			}
			downSize = temp;
		}
		else if (option == QString("-yscale")) {
			i++;
			if (i == argc) {
				break;
			}
			qreal temp = QString(argv[i]).toDouble();
			if (temp < 0) {
				cerr << "Maximum y-scale should be larger than zero." << endl;
				return false;
			}
			yscale = true;
			yscale_max = temp;
		}
		else if (option == QString("-feature")) {
			i++;
			if (i == argc) {
				break;
			}
			featureSet.insert(QString(argv[i]));
		}
		else {
			cerr << "Error: Unknown option was specified:" << option.toStdString() << "." << endl << endl;
			return false;
		}
		i++;
	}
	return true;
}


int main(int argc, char* argv[]) {

	QApplication app(argc, argv);

	//�I�v�V�������̎擾
	if (!ProcessArguments(argc, argv)) {
		cerr << "Error in processing arguments." << endl;
		showUsage();
		return 0;
	}

	//VPlotFile�̃I�[�v��
	VPlotFile::FileReader reader;
	if (!reader.setFile(vplotPath)) {
		cerr << "Couldn't open file \"" << vplotPath.toStdString() << "\"." << endl;
		showUsage();
		return 0;
	}
	VPlotFile::Header header = reader.getBasicTrackInfo();


	//GFF3�t�@�C���̃I�[�v��
	QFile in;
	in.setFileName(gff3Path);
	in.open(QIODevice::ReadOnly);
	if (!in.isOpen()) {
		cerr << "Couldn't open file \"" << gff3Path.toStdString() << "\"." << endl;
		showUsage();
		return 0;
	}
	QString line = QString(in.readLine().trimmed());
	if (!line.contains(GFF3Pragma)) {
		cerr << "Incorrect file was specified. \"" << gff3Path.toStdString() << "\" is not a gff3 file." << endl;
		showUsage();
		return 0;
	}

	//�o�̓t�@�C���̃I�[�v��
	QFile out(outPath);
	out.open(QIODevice::WriteOnly);
	if (!out.isOpen()) {
		cerr << "Couldn't open output file \"" << outPath.toStdString() << "\"." << endl;
		showUsage();
		return 0;
	}
	QTextStream outStream(&out);



	//�f�[�^�i�[�̈���m��
	//-upSize����0���o��-downSize�܂�
	//�܂�T�C�Y��upSize+downSize+1
	const int dataSize = upSize + downSize + 1;
	std::vector<std::vector<quint64> > depthMatrix(header.stepNum, std::vector<quint64>(dataSize, 0));
	int totalDepth = 0;

	//����GFF3�̃f�[�^��ǂݍ��݁AVPlot�t�@�C���̃f�[�^����荞��
	while (!in.atEnd()) {
		QString line = in.readLine().trimmed();
		//FASTA�̃v���O�}���o��������GFF�͏I���Ȃ̂Ŕ�����
		if (line.contains(FastaStart)) {
			break;
		}
		//���̍s��#�Ŏn�܂��Ă�����ǂݔ�΂�
		if (line.startsWith(QChar('#'))){
			continue;
		}
		QStringList cols = line.split(QChar('\t'));
		//�s�̗񐔂�9�ȊO�Ȃ�ǂݔ�΂�
		if (cols.size() != 9) {
			continue;
		}
		QString& target = cols[0];
		QString& database = cols[1];
		QString& type = cols[2];
		if(featureSet.size()>0){
			if (!featureSet.contains(type)) {
				continue;
			}
		}
		qint64 featureStart = cols[3].toInt();
		qint64 featureEnd = cols[4].toInt();
		//cols[5]
		qint64 strand;
		if (cols[6].contains(QChar('+'))) {
			strand = 1;
			if (featureStart < upSize) {
				continue;
			}
		}
		else {
			strand = -1;
			if (featureStart < downSize) {
				continue;
			}
		}
		//cols[7]
		QMap<QString, QString> attributeMap;
		QStringList attributes = cols[8].split(QChar(';'));
		for (int i = 0; i < attributes.size(); i++) {
			QStringList pair = attributes[i].split(QChar('='));
			if (pair.size() != 2) {
				continue;
			}
			attributeMap[pair[0]] = pair[1];
		}

		//VPlotFile����f�[�^�擾
		std::vector<std::vector<quint8> > data;
		quint64 dataStart, dataEnd;
		if (strand > 0) {
			dataStart = featureStart - downSize;
			dataEnd = featureStart + upSize;
			if (!reader.getData(target, dataStart, dataEnd, data)) {
				continue;
			}
			//�T�C�Y�����W�̕���
			for (int i = 0; i < header.stepNum; i++) {

				//�Q�m���ʒu�̕���
				for (int j = 0; j < dataSize; j++) {
					quint64 value = (quint64)(data[i][j]);
					depthMatrix[i][j] += value;
				}

			}


		}
		else {
			dataStart = featureStart + downSize;
			dataEnd = featureStart - upSize;
			if (!reader.getData(target, dataStart, dataEnd, data)) {
				continue;
			}
			
			//�T�C�Y�����W�̕���
			for (int i = 0; i < header.stepNum; i++) {

				//�Q�m���ʒu�̕���
				for (int j = 0; j < dataSize; j++) {
					quint64 value = (quint64)data[i][dataSize - j - 1];
					depthMatrix[i][j] += value;
				}

			}


		}
		totalDepth++;

	}

	std::vector<std::vector<qreal> > averageMatrix(header.stepNum, std::vector<qreal>(dataSize, 0));

	if (totalDepth > 1) {

		for (int i = 0; i < header.stepNum; i++) {
			for (int j = 0; j < dataSize; j++) {
				averageMatrix[i][j] = (qreal)depthMatrix[i][j] / (qreal)totalDepth;
				outStream << averageMatrix[i][j] << '\t';
			}
		}
		outStream << endl;

	}

	//�v���b�g�쐬
	QCustomPlot* customPlot = new QCustomPlot;
	qreal maxValue = 0;
	const qreal down_size = -((qreal)downSize);
	srand(1);
	QPen pen;
	for (int i = 0; i < header.stepNum; i++) {

		QVector<double> x_data, y_data;
		for (int j = 0; j < dataSize; j++) {

			qreal position = down_size + (double)j;
			qreal value = averageMatrix[i][j];
			maxValue = qMax(value, maxValue);
			x_data << position;
			y_data << value;

		}
		customPlot->addGraph();
		pen.setColor(QColor(qSin(i*0.3) * 100 + 100, qSin(i*0.6 + 0.7) * 100 + 100, qSin(i*0.4 + 0.6) * 100 + 100));
		customPlot->graph()->setData(x_data, y_data);

		customPlot->graph()->setName(QString("%1bp-%2bp").arg(i*header.sizeStep+header.minSize).arg((i+1)*header.sizeStep + header.minSize-1));

		customPlot->graph()->rescaleAxes(true);
		customPlot->graph()->setPen(pen);
		customPlot->graph()->setLineStyle(QCPGraph::lsLine);

	}

	// x���̏���
	customPlot->xAxis->setAutoTicks(true);
	customPlot->xAxis->setAutoTickLabels(true);
	customPlot->xAxis->setTickLength(0, 4);
	customPlot->xAxis->grid()->setVisible(true);
	customPlot->xAxis->setLabel(QString("Distance from Start Codon"));
	customPlot->xAxis->setRange(down_size, upSize*2);
	//customPlot->xAxis->rescale();

	// y���̏���
	customPlot->yAxis->setPadding(5); // a bit more space to the left border
	customPlot->yAxis->setLabel("Average mapped read depth");
	customPlot->yAxis->grid()->setVisible(true);
	customPlot->yAxis->rescale();
	customPlot->yAxis->setRangeLower(0);
	if (yscale) {
		customPlot->yAxis->setRangeUpper(yscale_max);
	}

	//legend
	customPlot->legend->setVisible(true);
	customPlot->legend->setFont(QFont("Helvetica", 9));
	customPlot->legend->setRowSpacing(-3);
	customPlot->legend->setBrush(QColor(255, 255, 255, 100));

	if (pngPath.size() > 0) {
		customPlot->savePng(pngPath);
	}
	
	if (pdfPath.size() > 0) {
		customPlot->savePdf(pdfPath);
	}
		

	return 0;

}
