#include "DesktopBasicTracks.h"

using namespace DesktopTrack;

DesktopBasicTracks::DesktopBasicTracks(QWidget* parent):
revisionManager(this),
pdialog(this),
QDialog(parent)
{
	setupUi(this);

	//species�֘A�̏�����
	connect(speciesComboBox, SIGNAL(currentIndexChanged(int)),
			this, SLOT(onChangeSpeciesComboBox(int)));

	//revision�֘A�̏�����
	connect(revisionComboBox, SIGNAL(currentIndexChanged(int)),
			this, SLOT(onChangeRevisionComboBox(int)));

	//RevisionManager�̃Z�b�g�A�b�v
	connect(launchRevisionManagerPushButton, SIGNAL(pressed()),
			this, SLOT(onClickLaunchRevisionManagerPushButton()));
	connect(&revisionManager, SIGNAL(revisionCreated()),
			this, SLOT(onCreateRevision()));

	//Config�֘A
	connect(overviewForegroundColorPushButton, SIGNAL(pressed()),
			this, SLOT(onClickOverviewForegroundColorPushButton()));
	connect(overviewBackgroundColorPushButton, SIGNAL(pressed()),
			this, SLOT(onClickOverviewBackgroundColorPushButton()));
	connect(overviewRegionPushButton, SIGNAL(pressed()),
			this, SLOT(onClickOverviewRegionPushButton()));
	connect(rulerForegroundColorPushButton, SIGNAL(pressed()),
			this, SLOT(onClickRulerForegroundPushButton()));
	connect(rulerBackgroundColorPushButton, SIGNAL(pressed()),
			this, SLOT(onClickRulerBackgroundColorPushButton()));
	connect(basecolorColorForAPushButton, SIGNAL(pressed()),
			this, SLOT(onClickBasecolorColorForAPushButton()));
	connect(basecolorColorForCPushButton, SIGNAL(pressed()),
			this, SLOT(onClickBasecolorColorForCPushButton()));
	connect(basecolorColorForGPushButton, SIGNAL(pressed()),
			this, SLOT(onClickBasecolorColorForGPushButton()));
	connect(basecolorColorForTPushButton, SIGNAL(pressed()),
			this, SLOT(onClickBasecolorColorForTPushButton()));
	connect(basecolorColorForNPushButton, SIGNAL(pressed()),
			this, SLOT(onClickBasecolorColorForNPushButton()));
	connect(overviewRowHeightSpinBox, SIGNAL(valueChanged(int)),
			this, SLOT(onChangeSpinBoxValue(int)));
	connect(rulerRowHeightSpinBox, SIGNAL(valueChanged(int)),
			this, SLOT(onChangeSpinBoxValue(int)));
	connect(basecolorRowHeightSpinBox, SIGNAL(valueChanged(int)),
			this, SLOT(onChangeSpinBoxValue(int)));

	//Restore button
	connect(restorePushButton, SIGNAL(pressed()),
			this, SLOT(onClickRestorePushButton()));

	//�^�C�}�[�̏����ݒ�
	timer.setSingleShot(false);
	timer.setInterval(500);

	//�v���r���[�̈�̏�����
	QScrollArea* scrollArea = new QScrollArea(this);
	scrollArea->setContentsMargins(0, 0, 0, 0);
	scrollArea->setBackgroundRole(QPalette::Dark);

	previewLabel = new QLabel(scrollArea);
	previewLabel->setLineWidth(0);
	previewLabel->setScaledContents(true);

	scrollArea->setWidget(previewLabel);

	QGridLayout* layout = new QGridLayout(previewFrame);
	layout->setMargin(0);
	layout->addWidget(scrollArea);
	
	previewFrame->setLineWidth(0);
	previewFrame->setLayout(layout);

	connect(targetComboBox, SIGNAL(currentIndexChanged(int)),
			this, SLOT(onChangeTargetComboBoxSelect(int)));

	connect(showPreviewButton, SIGNAL(pressed()),
			this, SLOT(onClickPreviewPushButton()));

	connect(&imageProcess, SIGNAL(finished(int, QProcess::ExitStatus)),
			this, SLOT(onImageReadyReadStdout(int, QProcess::ExitStatus)));

	connect(&indexImageProcess, SIGNAL(finished(int, QProcess::ExitStatus)),
			this, SLOT(onIndexImageReadyReadStdout(int, QProcess::ExitStatus)));

	pdialog.cancel();

	setUpSpeciesComboBox();

	


}

void DesktopBasicTracks::onClickLaunchRevisionManagerPushButton(void)
{
	revisionManager.show();
}

void DesktopBasicTracks::onCreateRevision(void)
{
	setUpSpeciesComboBox();
}

void DesktopBasicTracks::setUpSpeciesComboBox(void)
{

	//SpeciesComboBox���N���A���ď�����
	speciesComboBox->clear();
	revisionComboBox->clear();

	QStringList species_list;
	if(!revisionManager.getSpecies(species_list)){
		speciesComboBox->setEnabled(false);
		configurationGroupBox->setEnabled(false);
		onChangeRevisionComboBox(-1);
		return;
	}
	for(int i=0; i<species_list.size(); i++){
		speciesComboBox->addItem(species_list[i]);
	}
	speciesComboBox->setEnabled(true);
}

void DesktopBasicTracks::onChangeSpeciesComboBox(int index)
{
	//RevisionComboBox��������
	revisionComboBox->clear();

	QString species = speciesComboBox->itemText(index);
	QStringList revision_list;
	if(!revisionManager.getRevision(species, revision_list)){
		speciesComboBox->setEnabled(false);
		onChangeRevisionComboBox(-1);
		return;
	}

	if(revision_list.size()==0){
		revisionComboBox->setEnabled(false);
		configurationGroupBox->setEnabled(false);
	}
	else{
		for(int i=0; i<revision_list.size(); i++){
			revisionComboBox->addItem(revision_list[i]);
		}
		configurationGroupBox->setEnabled(true);
		revisionComboBox->setEnabled(true);
	}
	onChangeRevisionComboBox(-1);
}

void DesktopBasicTracks::onCreateBinseq(void)
{
	onChangeRevisionComboBox(-1);
}

void DesktopBasicTracks::onChangeRevisionComboBox(int /*index*/)
{
	//Species&Revision
	QString species=speciesComboBox->itemText(speciesComboBox->currentIndex());
	QString revision=revisionComboBox->itemText(revisionComboBox->currentIndex());
	//RevisionManager����Revision�̃f�B���N�g�����擾
	QString revision_dir_path;
	if(!revisionManager.getRivisionDir(species, revision, revision_dir_path)){
		QMessageBox::warning(this, "Warning", "Can not open Revisions directory");
		return;
	}
	QDir revision_dir(revision_dir_path);
	//BinSeq��T��
	QString binseq_path=revision_dir.filePath(BinSeqFileTemp.arg(species).arg(revision));
	BinSeq::FileReader reader;
	if(reader.setFile(binseq_path)){
		//BinSeq�t�@�C����Config�𓾂�
		header=reader.getTrackConfig();
		//�e�{�^����������
		overviewForegroundColorWidget->SetColor(header.ovFgColor);
		overviewBackgroundColorWidget->SetColor(header.ovBgColor);
		overviewRegionColorWidget->SetColor(header.ovMarkColor);
		overviewRowHeightSpinBox->setValue(header.ovRowHeight);
		rulerForegroundColorWidget->SetColor(header.rlFgColor);
		rulerBackgroundColorWidget->SetColor(header.rlBgColor);
		rulerRowHeightSpinBox->setValue(header.rlRowHeight);
		basecolorColorForAWidget->SetColor(header.bgColorForA);
		basecolorColorForCWidget->SetColor(header.bgColorForC);
		basecolorColorForGWidget->SetColor(header.bgColorForG);
		basecolorColorForTWidget->SetColor(header.bgColorForT);
		basecolorColorForNWidget->SetColor(header.bgColorForN);
		basecolorRowHeightSpinBox->setValue(header.bgRowHeight);
		//�{�^���̕ύX
		restorePushButton->setEnabled(false);
		createUpdatePushButton->setText(tr("Update Track"));
		createUpdatePushButton->setEnabled(false);
		//�{�^�����ʂ̕ύX
		disconnect(createUpdatePushButton, SIGNAL(pressed()), this, SLOT(createTrack()));
		connect(createUpdatePushButton, SIGNAL(pressed()), this, SLOT(updateTrack()));
		
		//preview�̈�̏�����
		targetComboBox->clear();
		QList<BinSeq::Target> targetList=reader.getTargetList();
		BinSeq::TargetLess targetLess;
		qSort(targetList.begin(), targetList.end(), targetLess);
		for(int i=0; i<targetList.size(); i++){
			BinSeq::Target& target=targetList[i];
			targetComboBox->addItem(target.targetName, QVariant(target.targetLength));
		}
		onClickPreviewPushButton();

	}
	else{
		//Config�̏����l�𓾂�
		BinSeq::Header temp;
		header=temp;
		header.species=species;
		header.revision=revision;
		//�e�{�^����������
		overviewForegroundColorWidget->SetColor(header.ovFgColor);
		overviewBackgroundColorWidget->SetColor(header.ovBgColor);
		overviewRegionColorWidget->SetColor(header.ovMarkColor);
		overviewRowHeightSpinBox->setValue(header.ovRowHeight);
		rulerForegroundColorWidget->SetColor(header.rlFgColor);
		rulerBackgroundColorWidget->SetColor(header.rlBgColor);
		rulerRowHeightSpinBox->setValue(header.rlRowHeight);
		basecolorColorForAWidget->SetColor(header.bgColorForA);
		basecolorColorForCWidget->SetColor(header.bgColorForC);
		basecolorColorForGWidget->SetColor(header.bgColorForG);
		basecolorColorForTWidget->SetColor(header.bgColorForT);
		basecolorColorForNWidget->SetColor(header.bgColorForN);
		basecolorRowHeightSpinBox->setValue(header.bgRowHeight);
		//�{�^���̕ύX
		restorePushButton->setEnabled(false);
		createUpdatePushButton->setText(tr("Create Track"));
		createUpdatePushButton->setEnabled(true);
		//�{�^�����ʂ̕ύX
		disconnect(createUpdatePushButton, SIGNAL(pressed()), this, SLOT(updateTrack()));
		connect(createUpdatePushButton, SIGNAL(pressed()), this, SLOT(createTrack()));

		//preview�̈�̏�����
		targetComboBox->clear();

	}
}

void DesktopBasicTracks::createTrack(void)
{
	//�Q�x�����֎~
	createUpdatePushButton->setEnabled(false);
	restorePushButton->setEnabled(false);
	//���݂�species&revision���擾
	QString species=speciesComboBox->itemText(speciesComboBox->currentIndex());
	QString revision=revisionComboBox->itemText(revisionComboBox->currentIndex());
	//revision_dir���擾
	QString revision_dir_path;
	if(!revisionManager.getRivisionDir(species, revision, revision_dir_path)){	
		return;
	}
	QDir revision_dir(revision_dir_path);
	//RevisionMamager����SeqInfoList���擾
	SeqInfoList seqInfoList;
	revisionManager.getSeqInfoList(species, revision, seqInfoList);	
	//BinSeq�̃t�@�C��������
	binseq_path=revision_dir.filePath(BinSeqFileTemp.arg(species).arg(revision));

	header.species=species;
	header.revision=revision;
	header.ovFgColor=overviewForegroundColorWidget->GetColor();
	header.ovBgColor=overviewBackgroundColorWidget->GetColor();
	header.ovMarkColor=overviewRegionColorWidget->GetColor();
	header.ovRowHeight=overviewRowHeightSpinBox->value();
	header.rlFgColor=rulerForegroundColorWidget->GetColor();
	header.rlBgColor=rulerBackgroundColorWidget->GetColor();
	header.rlRowHeight=rulerRowHeightSpinBox->value();
	header.bgColorForA=basecolorColorForAWidget->GetColor();
	header.bgColorForC=basecolorColorForCWidget->GetColor();
	header.bgColorForG=basecolorColorForGWidget->GetColor();
	header.bgColorForT=basecolorColorForTWidget->GetColor();
	header.bgColorForN=basecolorColorForNWidget->GetColor();
	header.bgRowHeight=basecolorRowHeightSpinBox->value();

	//Creator��������
	creator.initialize(binseq_path, header, seqInfoList);

	//timer�Ƃ̘A��
	connect(&timer, SIGNAL(timeout()),
			this, SLOT(onTimeOutCreateBinseq()));

	//dialog�Ƃ̘A��
	pdialog.setValue(0);
	pdialog.setLabelText(tr("Creating a track.."));
	connect(&pdialog, SIGNAL(canceled()),
			this, SLOT(onClickCancelPushButton()));

	//run
	creator.setOrder(true);
	creator.start();
	timer.start();
	pdialog.exec();

}

void DesktopBasicTracks::onTimeOutCreateBinseq(void)
{
	BinSeq::FileCreator::Process process_status;
	quint64	prosessed_data;
	quint64	total_data;
	creator.getProcessStatus(process_status, prosessed_data, total_data);
	int progress;
	if(total_data!=0){
		progress = (int)((100*prosessed_data)/total_data);
	}
	else{
		progress = 0;
	}
	QFileInfo info(binseq_path);
	switch(process_status){

		case BinSeq::FileCreator::processing:
			pdialog.setValue(progress);
			break;

		case BinSeq::FileCreator::stopped:

			timer.stop();
			if(!info.exists()){
				QFile file(binseq_path);
				file.remove();
			}
			disconnect(&timer, SIGNAL(timeout()),
					this, SLOT(onTimeOutCreateBinseq()));
			disconnect(&pdialog, SIGNAL(canceled()),
					this, SLOT(onClickCancelPushButton()));
			pdialog.cancel();
			break;

		case BinSeq::FileCreator::failed:

			timer.stop();
			if(!info.exists()){
				QFile file(binseq_path);
				file.remove();
			}
			disconnect(&timer, SIGNAL(timeout()),
					this, SLOT(onTimeOutCreateBinseq()));
			disconnect(&pdialog, SIGNAL(canceled()),
					this, SLOT(onClickCancelPushButton()));
			pdialog.cancel();
			break;

		case BinSeq::FileCreator::finished:

			timer.stop();
			disconnect(&timer, SIGNAL(timeout()),
					this, SLOT(onTimeOutCreateBinseq()));
			disconnect(&pdialog, SIGNAL(canceled()),
					this, SLOT(onClickCancelPushButton()));
			pdialog.setValue(100);
			pdialog.cancel();
			onChangeRevisionComboBox(revisionComboBox->currentIndex());
			onClickPreviewPushButton();
			break;

	}

}

void DesktopBasicTracks::onClickCancelPushButton(void)
{
	creator.setOrder(false);
}


void DesktopBasicTracks::CheckValueChanged(void)
{
	if(overviewForegroundColorWidget->GetColor()!=header.ovFgColor){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(overviewBackgroundColorWidget->GetColor()!=header.ovBgColor){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(overviewRegionColorWidget->GetColor()!=header.ovMarkColor){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(overviewRowHeightSpinBox->value()!=header.ovRowHeight){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(rulerForegroundColorWidget->GetColor()!=header.rlFgColor){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(rulerBackgroundColorWidget->GetColor()!=header.rlBgColor){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(rulerRowHeightSpinBox->value()!=header.rlRowHeight){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(basecolorColorForAWidget->GetColor()!=header.bgColorForA){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(basecolorColorForCWidget->GetColor()!=header.bgColorForC){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(basecolorColorForGWidget->GetColor()!=header.bgColorForG){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(basecolorColorForTWidget->GetColor()!=header.bgColorForT){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(basecolorColorForNWidget->GetColor()!=header.bgColorForN){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	if(basecolorRowHeightSpinBox->value()!=header.bgRowHeight){
		createUpdatePushButton->setEnabled(true);
		restorePushButton->setEnabled(true);
		return;
	}
	createUpdatePushButton->setEnabled(false);
	restorePushButton->setEnabled(false);
}

void DesktopBasicTracks::onChangeSpinBoxValue(int /*value*/){
	CheckValueChanged();
}

void DesktopBasicTracks::onClickOverviewForegroundColorPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	overviewForegroundColorWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickOverviewBackgroundColorPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	overviewBackgroundColorWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickOverviewRegionPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	overviewRegionColorWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickRulerForegroundPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	rulerForegroundColorWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickRulerBackgroundColorPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	rulerBackgroundColorWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickBasecolorColorForAPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	basecolorColorForAWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickBasecolorColorForCPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	basecolorColorForCWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickBasecolorColorForGPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	basecolorColorForGWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickBasecolorColorForTPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	basecolorColorForTWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickBasecolorColorForNPushButton(void)
{
	QColor color = QColorDialog::getColor(QColor::fromRgb(0, 0, 0));
	basecolorColorForNWidget->SetColor(color);
	CheckValueChanged();
}

void DesktopBasicTracks::onClickRestorePushButton(void)
{
	overviewForegroundColorWidget->SetColor(header.ovFgColor);
	overviewBackgroundColorWidget->SetColor(header.ovBgColor);
	overviewRegionColorWidget->SetColor(header.ovMarkColor);
	overviewRowHeightSpinBox->setValue(header.ovRowHeight);
	rulerForegroundColorWidget->SetColor(header.rlFgColor);
	rulerBackgroundColorWidget->SetColor(header.rlBgColor);
	rulerRowHeightSpinBox->setValue(header.rlRowHeight);
	basecolorColorForAWidget->SetColor(header.bgColorForA);
	basecolorColorForCWidget->SetColor(header.bgColorForC);
	basecolorColorForGWidget->SetColor(header.bgColorForG);
	basecolorColorForTWidget->SetColor(header.bgColorForT);
	basecolorColorForNWidget->SetColor(header.bgColorForN);
	basecolorRowHeightSpinBox->setValue(header.bgRowHeight);
	configurationGroupBox->update();
	restorePushButton->setEnabled(false);
	createUpdatePushButton->setEnabled(false);
}

void DesktopBasicTracks::updateTrack(void)
{

	//Species&Revision
	QString species=speciesComboBox->itemText(speciesComboBox->currentIndex());
	QString revision=revisionComboBox->itemText(revisionComboBox->currentIndex());

	//RevisionManager����Revision�̃f�B���N�g�����擾
	QString revision_dir_path;
	if(!revisionManager.getRivisionDir(species, revision, revision_dir_path)){
		return;
	}
	QDir revision_dir(revision_dir_path);
	//BinSeq�̃t�@�C��������
	binseq_path=revision_dir.filePath(BinSeqFileTemp.arg(species).arg(revision));

	//�Ώ�binseq��ǂݍ���
	BinSeq::FileReader reader;
	if(!reader.setFile(binseq_path)){
		return;
	}

	//�X�V�f�[�^�̎�荞��
	header.ovFgColor=overviewForegroundColorWidget->GetColor();
	header.ovBgColor=overviewBackgroundColorWidget->GetColor();
	header.ovMarkColor=overviewRegionColorWidget->GetColor();
	header.ovRowHeight=overviewRowHeightSpinBox->value();
	header.rlFgColor=rulerForegroundColorWidget->GetColor();
	header.rlBgColor=rulerBackgroundColorWidget->GetColor();
	header.rlRowHeight=rulerRowHeightSpinBox->value();
	header.bgColorForA=basecolorColorForAWidget->GetColor();
	header.bgColorForC=basecolorColorForCWidget->GetColor();
	header.bgColorForG=basecolorColorForGWidget->GetColor();
	header.bgColorForT=basecolorColorForTWidget->GetColor();
	header.bgColorForN=basecolorColorForNWidget->GetColor();
	header.bgRowHeight=basecolorRowHeightSpinBox->value();

	//�t�@�C���X�V
	if(!reader.updateConfig(header)){
		return;
	}
	
	//GUI�X�V
	restorePushButton->setEnabled(false);
	createUpdatePushButton->setEnabled(false);
	onClickPreviewPushButton();

}

void DesktopBasicTracks::
onClickPreviewPushButton(void){

	QString currentDirPath = QDir::currentPath();
	QDir::setCurrent(QApplication::applicationDirPath());

	QString track_name;
	if(overviewRadioButton->isChecked()){
		track_name = "overview";
	}
	else if(rulerRadioButton->isChecked()){
		track_name = "ruler";
	}
	else{
		track_name = "basecolor";
	}
	QString env_temp
		= "QUERY_STRING=track_name=%1&track_layer=%2&species=%3&revision=%4&target=%5&start=%6&end=%7&width=%8";
#ifdef WIN32
	QString program	= "./BasicTracks.exe";
#else
	QString program	= "./BasicTracks";
#endif
	QFileInfo info(program);
	if(!info.exists()){
		QDir::setCurrent(currentDirPath);
		return;
	}
	//Species&Revision
	QString species=speciesComboBox->itemText(speciesComboBox->currentIndex());
	QString revision=revisionComboBox->itemText(revisionComboBox->currentIndex());
	QString target = targetComboBox->itemText(targetComboBox->currentIndex());
	QString start=startLineEdit->text();
	QString end=endLineEdit->text();
	QString width=pixelWidthLineEdit->text();

	targetComboBox->setEnabled(false);
	startLineEdit->setEnabled(false);
	endLineEdit->setEnabled(false);
	pixelWidthLineEdit->setEnabled(false);
	showPreviewButton->setEnabled(false);
	imageOk = false;
	indexImageOk = false;

	//���x���Ƀe�L�X�g���Z�b�g
	previewLabel->setGeometry(0, 0, previewFrame->width(), previewFrame->height());
	previewLabel->setAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
	previewLabel->setText(tr("Retrieving image data ..."));

	QStringList env;
	env << env_temp.arg(track_name).arg(QString("image")).arg(species).arg(revision).arg(target).arg(start).arg(end).arg(width);
	imageProcess.setEnvironment(env);
	imageProcess.start(program);

	env.clear();
	env << env_temp.arg(track_name).arg(QString("index")).arg(species).arg(revision).arg(target).arg(start).arg(end).arg(width);
	indexImageProcess.setEnvironment(env);
	indexImageProcess.start(program);

	QDir::setCurrent(currentDirPath);
	
}

void DesktopBasicTracks::
onChangeTargetComboBoxSelect(int index)
{
	if(index==-1){
		if(previewGroupBox->isEnabled()){
			previewGroupBox->setEnabled(false);
		}
		targetComboBox->clear();
		startLineEdit->setText("");
		endLineEdit->setText("");
		pixelWidthLineEdit->setText("");
	}
	else{
		if(!previewGroupBox->isEnabled()){
			previewGroupBox->setEnabled(true);
		}
		quint32 target_length
			= targetComboBox->itemData(index).toUInt();
		startLineEdit->setText(QString::number(1));
		endLineEdit->setText(QString::number(target_length));
		pixelWidthLineEdit->setText(QString::number(600));
	}
}

void DesktopBasicTracks::
onImageReadyReadStdout(int exitCode, QProcess::ExitStatus exitStatus)
{
	image.loadFromData(imageProcess.readAllStandardOutput(), ".png");
	imageOk=true;
	if(imageOk&&indexImageOk){
		targetComboBox->setEnabled(true);
		startLineEdit->setEnabled(true);
		endLineEdit->setEnabled(true);
		pixelWidthLineEdit->setEnabled(true);
		showPreviewButton->setEnabled(true);
		drawPreviw();
	}
}

void DesktopBasicTracks::
onIndexImageReadyReadStdout(int exitCode, QProcess::ExitStatus exitStatus)
{
	indexImage.loadFromData(indexImageProcess.readAllStandardOutput(), ".png");
	indexImageOk=true;
	if(imageOk&&indexImageOk){
		targetComboBox->setEnabled(true);
		startLineEdit->setEnabled(true);
		endLineEdit->setEnabled(true);
		pixelWidthLineEdit->setEnabled(true);
		showPreviewButton->setEnabled(true);
		drawPreviw();
	}
}

void DesktopBasicTracks::drawPreviw(void)
{

	quint32 width = image.width()+indexImage.width();
	quint32 height = image.height()>indexImage.height()?image.height():indexImage.height();
	QPixmap pixmap(width, height);
	QPainter painter(&pixmap);
	painter.drawImage(0, 0, indexImage);
	painter.drawImage(indexImage.width(), 0, image);
	previewLabel->setPixmap(pixmap);
	previewLabel->setGeometry(0, 0, width, height);

}