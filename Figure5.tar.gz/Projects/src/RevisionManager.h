#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif
#include <QtXml>

#ifndef REVISION_MANAGER_H
#define REVISION_MANAGER_H

#include "ui_RevisionManager.h"

#include "SeqInfo.h"
#include "SeqInfoListTableModel.h"
#include "QFasta.h"
#include "DesktopTrackCommon.h"
#include "FileCopy.h"
#include "CreateFasta.h"

namespace DesktopTrack{

	class RevisionManager : public QDialog, Ui::RevisionManager
	{
		Q_OBJECT
	public:
		RevisionManager(QWidget* parent=0);

		//�햼�̃��X�g��Ԃ�
		bool			getSpecies(		QStringList& speciesTo);

		//��̓o�^�����邩�ǂ�����Ԃ�
		bool			speciesExists(	const QString& species);

		//���o�^����
		bool			putSpecies(		const QString& species);

		//���r�W�������̃��X�g��Ԃ�
		bool			getRevision(	const QString& species, 
										QStringList& revisionsTo);

		//���r�W�����̓o�^�����邩�ǂ�����Ԃ�
		bool			revisionExists(	const QString& species,
										const QString& revision);

		bool			getRivisionDir(	const QString& species,
										const QString& revision,
										QString& revisionDirTo);

		//�z�񖼂ƃT�C�Y�̃y�A�f�[�^�̃��X�g��Ԃ�
		bool			getTarget(		const QString& species, 
										const QString& revision, 
										QList<QPair<QString, quint32> >& queryListTo);

		//SeqInfoList��Ԃ�
		bool			getSeqInfoList(	const QString& species,
										const QString& revision,
										SeqInfoList& seqInfoListTo);

		//�Q�Ƃ��Ă���t�@�X�^�t�@�C���̃��X�g��Ԃ�
		bool			getFastaPath(	const QString& species, 
										const QString& revision, 
										QString& fastaPathTo);

	signals:
		void			revisionCreated(void);

	private slots:


		//Species�o�^�֘A
		void			onSelectSpeciesComboBox(int index);
		void			onEditSpeciesLineEdit(const QString& text);
		void			onClickCreateSpeciesPushButton(void);

		//Revision�o�^�֘A
		void			onSelectRevisionComboBox(int index);
		void			onEditRevisionLineEdit(const QString& text);
		void			onClickFileSelectPushButton(void);
		void			onFilesSelected(const QStringList& files);
		void			onChangeFileListSelect(const QModelIndex&, const QModelIndex&);
		void			onClickRemoveFilePushButton(void);
		void			onClickStartAnalysisPushButton(void);

		void			onTimeOutFastaFileAnalysis(void);
		void			onCancelFileAnalysis(void);

		void			onPushCreateRevisionButton(void);

        void            onTimeOutFileCopy(void);
		void			onCancelFileCopy(void);

        void            onTimeOutCreateFasta(void);
		void			onCancelCreateFasta(void);

	private:

		QFileDialog		FileDialog;
		QStringList		FileList;
		QStringListModel
						FileListModel;

		QString			binseqSpecies;
		QString			binseqRevision;

		//��͗p
		QTimer			timer;
		QProgressDialog	pdialog;
		FastaFileAnalyzer
						fastaFileAnalyzer;
		SeqInfoListTableModel
						seqInfoListTableModel;

        //
        FileCopy        fileCopy;
        CreateFasta     createFasta;

		//xml�t�@�C���쐬
		QDomDocument	doc;
						
		/*---------------------------------------------------------------
			Private �֐��Q
		---------------------------------------------------------------*/
//		bool			fileCopy(	const QStringList& origFiles,
//									const QStringList& destFiles);

//		bool			createFasta(const QString& destFasta,
//									const SeqInfoList& seqInfoList);

	};

};

#endif 
