#include "BasicTracksCGIParam.h"

using namespace DesktopTrack;

BasicTracksCGIParam::BasicTracksCGIParam(void)
:start_from(0), end_to(0), pixel_width(0), row_height(0)
{

	QString query_string;
	if(std::getenv( "SERVER_NAME" )!=0){
		if(std::getenv("HTTPS")!=0){
			address=QString("https://")+QString(std::getenv("SERVER_NAME"))+QString(std::getenv("SCRIPT_NAME"));
		}
		else{
			address=QString("http://")+QString(std::getenv("SERVER_NAME"))+QString(std::getenv("SCRIPT_NAME"));
		}
		if(std::getenv( "QUERY_STRING" )!=0){
			query_string = std::getenv("QUERY_STRING");
		}
		is_cgi=true;
	}
	else{
		address=QCoreApplication::arguments().at(0);
		if(std::getenv( "QUERY_STRING" )!=0){
			query_string = std::getenv("QUERY_STRING");
		}
		is_cgi=false;
	}

	QStringList list1 = query_string.split(QRegExp("[&?]"));
	for(QStringList::iterator itr=list1.begin();
		itr!=list1.end(); itr++)
	{
		QString BasicTracks = *itr;
		QStringList list2 = itr->split("=");
		if(list2.size()<2){
			continue;
		}
		if(list2[0]=="track_layer"){
			track_layer = list2[1];
		}
		else if(list2[0]=="track_name"){
			track_name = list2[1];
		}
		else if(list2[0]=="species"){
			species = list2[1];
		}
		else if(list2[0]=="revision"){
			revision = list2[1];
		}
		else if(list2[0]=="target"){
			target_name = list2[1];
		}
		else if(list2[0]=="start"){
			start_from = list2[1].toUInt();
		}
		else if(list2[0]=="end"){
			end_to = list2[1].toUInt();
		}
		else if(list2[0]=="width"){
			pixel_width = list2[1].toUInt();
		}
		else if(list2[0]=="foreground_color"){
			foreground_color = list2[1];
		}
		else if(list2[0]=="background_color"){
			background_color = list2[1];
		}
		else if(list2[0]=="dispregion_color"){
			dispregion_color = list2[1];
		}
		else if(list2[0]=="row_height"){
			row_height = list2[1].toUInt();
		}
		else if(list2[0]=="color_for_a"){
			color_for_a = list2[1];
		}
		else if(list2[0]=="color_for_c"){
			color_for_c = list2[1];
		}
		else if(list2[0]=="color_for_g"){
			color_for_g = list2[1];
		}
		else if(list2[0]=="color_for_t"){
			color_for_t = list2[1];
		}
		else if(list2[0]=="color_for_n"){
			color_for_n = list2[1];
		}
		else{
			anotherParam.push_back(qMakePair(list2[0].trimmed(), list2[1].trimmed()));
		}
	}
}

