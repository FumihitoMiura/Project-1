#ifndef CREATEFASTA_H
#define CREATEFASTA_H

#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif
#include "SeqInfo.h"

namespace DesktopTrack{

    class CreateFasta:public QThread{
        Q_OBJECT
    public:
        enum Process{processing, failed, stopped, finished};
        CreateFasta(QObject* parent=0);
        bool setFiles(
                const QString& destFasta,
                const SeqInfoList& seqInfoList);
        //Thread Safe
        void setOrder(bool proceed);
        //Thread Safe
        void getProcessStatus(
                Process& process_status,
                quint64& prosessed_data,
                quint64& total_data);

    private:
        //-----thread�ԒʐM�p�ϐ���������-----
        QMutex	mutex;
        bool	promoteProcess;
        Process processStatus;
        quint64	processedData;
        quint64	totalData;
        //-----thread�ԒʐM�p�ϐ������܂�-----

        QString destFasta;
        SeqInfoList seqInfoList;

        void run(void);

        //Thread Safe
        void setProcessStatus(	const Process& process_status,
                                const quint64& prosessed_data,
                                const quint64& total_data);
        //Thread Safe
        bool getOrder(void);
    };

};

#endif // CREATEFASTA_H
