#include <QtCore>

#ifndef Q_FASTA_FILE
#define Q_FASTA_FILE

namespace DesktopTrack{

	class QInputFastaFile{
	public:
				QInputFastaFile(QIODevice* device=0);
		void	setDevice(QIODevice* file);
		bool	getNextSeq(QString& seq, QString& seq_name, bool case_sensitive=false);
	private:
		QString		seq_name;
		QIODevice*	device;
		bool		isReady;
	};

	class QOutputOFastaFile{
	public:
				QOutputOFastaFile(QIODevice* device=0);

		void	setDevice(QIODevice* device);
		bool	putNextSeq(const QString& seq, const QString& seq_name);
		bool	putNextSeq(const QByteArray& seq, const QString& seq_name);
	private:
		QIODevice*	device;
		bool		isReady;
	};

};


#endif //Q_FASTA_FILE




