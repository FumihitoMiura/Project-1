#include "ColorIndicatorWidget.h"

ColorIndicatorWidget::
ColorIndicatorWidget(QWidget* parent)
: QWidget(parent)
{
	//�f�t�H���g�F
	bgColor = Qt::black;
	bgColorName = bgColor.name();
	fgColor.setRgb(255-bgColor.red(), 255-bgColor.green(), 255-bgColor.blue());
	fgColorName = fgColor.name();
}


void ColorIndicatorWidget::paintEvent(QPaintEvent* events)
{
	if(this->isEnabled()){
		QPainter painter(this);
		QPen pen(Qt::black);
		painter.setPen(pen);
		QBrush brush(bgColor);
		painter.setBrush(brush);
		painter.drawRect(0, 0, width()-1, height()-1);
		pen.setColor(fgColor);
		painter.setPen(pen);
		painter.drawText(rect(), Qt::AlignCenter, bgColor.name().toUpper());
	}
	else{
		QWidget::paintEvent(events);
	}
}

void ColorIndicatorWidget::SetColor(const QColor& color)
{
	bgColor = color;
	bgColorName = bgColor.name().toUpper();
	fgColor.setRgb(255-bgColor.red(), 255-bgColor.green(), 255-bgColor.blue());
	fgColorName = fgColor.name().toUpper();
	update();
}

const QString& ColorIndicatorWidget::GetColorName(void) const
{
	return bgColorName;
}

const QColor& ColorIndicatorWidget::GetColor(void) const
{
	return bgColor;
}
