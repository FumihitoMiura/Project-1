#include <QtCore>
#include <QtGui>
#include "DesktopBasicTracks.h"

int main(int argc, char* argv[]){
	
	QApplication app(argc, argv);
	DesktopTrack::DesktopBasicTracks* mainWindow = new DesktopTrack::DesktopBasicTracks;
	mainWindow->show();
	app.exec();

}

