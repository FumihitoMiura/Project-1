#include <QtCore>
#include <QtGui>
#include <QtXml>

#ifndef DESKTOP_BASIC_TRACKS_H
#define DESKTOP_BASIC_TRACKS_H

#include "ui_DesktopBasicTracks.h"
#include "RevisionManager.h"
#include "DesktopTrackCommon.h"
#include "BinSeq.h"

namespace DesktopTrack{

	class DesktopBasicTracks : public QDialog, Ui::DesktopBasicTracks
	{
		Q_OBJECT
	public:
		DesktopBasicTracks(QWidget* parent=0);

	private slots:

		//Revision�Ǘ��֌W
		void			onClickLaunchRevisionManagerPushButton(void);
		void			onCreateRevision(void);
		void			onCreateBinseq(void);

		//Revision�I��
		void			setUpSpeciesComboBox(void);
		void			onChangeSpeciesComboBox(int index);
		void			onChangeRevisionComboBox(int index);

		//Config�֘A
		void			onClickOverviewForegroundColorPushButton(void);
		void			onClickOverviewBackgroundColorPushButton(void);
		void			onClickOverviewRegionPushButton(void);
		void			onClickRulerForegroundPushButton(void);
		void			onClickRulerBackgroundColorPushButton(void);
		void			onClickBasecolorColorForAPushButton(void);
		void			onClickBasecolorColorForCPushButton(void);
		void			onClickBasecolorColorForGPushButton(void);
		void			onClickBasecolorColorForTPushButton(void);
		void			onClickBasecolorColorForNPushButton(void);
		void			onChangeSpinBoxValue(int);

		void			onClickRestorePushButton(void);

		void			createTrack(void);
		void			updateTrack(void);
		void			onClickCancelPushButton(void);

		void			onTimeOutCreateBinseq(void);

		//Preview�֘A
		void			onClickPreviewPushButton(void);
		void			onChangeTargetComboBoxSelect(int index);
		void			onImageReadyReadStdout(int exitCode, QProcess::ExitStatus exitStatus);
		void			onIndexImageReadyReadStdout(int exitCode, QProcess::ExitStatus exitStatus);

	private:

		RevisionManager revisionManager;

		BinSeq::Header	header;
		
		//
		void			CheckValueChanged(void);



		void			drawPreviw(void);

		BinSeq::FileCreator	creator;
		QTimer				timer;
		QProgressDialog		pdialog;
		QString				binseq_path;


		//preview
		QLabel*				previewLabel;
		QProcess			imageProcess;
		QImage				image;
		bool				imageOk;
		QProcess			indexImageProcess;
		QImage				indexImage;
		bool				indexImageOk;

	};
};

#endif

