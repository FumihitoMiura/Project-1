#include "VPlotFile.h"

using namespace DesktopTrack::VPlotFile;

/*---------------------------------------

		namespace DesktopTrack
		namespace VPlotFile
		class Header

 ---------------------------------------*/

Header::Header(void):
magic(2346),
version(1),
targetListOffset(0),
targetListDataSize(0),
targetListDataCount(0),
rowHeight(RowHeight),
fontSize(FontSize),
fgColor(FgColor),
bgColor(BgColor),
anColor(AnColor),
minSize(0),
sizeStep(0),
stepNum(0){}

Header::Header(const Header& original):
magic(original.magic),
version(original.version),
trackName(original.trackName),
species(original.species),
revision(original.revision),
targetListOffset(original.targetListOffset),
targetListDataSize(original.targetListDataSize),
targetListDataCount(original.targetListDataCount),
rowHeight(original.rowHeight),
fontSize(original.fontSize),
fgColor(original.fgColor),
bgColor(original.bgColor),
anColor(original.anColor),
minSize(original.minSize),
sizeStep(original.sizeStep),
stepNum(original.stepNum){}


Header& Header::operator =(const Header& original)
{
	magic=original.magic;
	version=original.version;
	trackName=original.trackName;
	species=original.species;
	revision=original.revision;
	targetListOffset=original.targetListOffset;
	targetListDataSize=original.targetListDataSize;
	targetListDataCount=original.targetListDataCount;
	rowHeight=original.rowHeight;
	fontSize=original.fontSize;
	fgColor=original.fgColor;
	bgColor=original.bgColor;
	anColor=original.anColor;
	minSize = original.minSize;
	sizeStep = original.sizeStep;
	stepNum = original.stepNum;
	return *this;
}

bool Header::isCorrectFile(void)
{
	if(magic==2346){
		if(version==1){
			return true;
		}
		else{
			return false;
		}
	}
	else{
		return false;
	}
}

void Header::putSerialized(QDataStream& out)
{
	out << magic
		<< version
		<< trackName
		<< species
		<< revision
		<< targetListOffset
		<< targetListDataSize
		<< targetListDataCount
		<< rowHeight
		<< fontSize
		<< fgColor
		<< bgColor
		<< anColor
		<< minSize
		<< sizeStep
		<< stepNum;
}

void Header::getSerialized(QDataStream& in)
{
	in  >> magic
		>> version
		>> trackName
		>> species
		>> revision
		>> targetListOffset
		>> targetListDataSize
		>> targetListDataCount
		>> rowHeight
		>> fontSize
		>> fgColor
		>> bgColor
		>> anColor
		>> minSize
		>> sizeStep
		>> stepNum;

}

/*---------------------------------------

		namespace DesktopTrack
		namespace VPlotFile
		class Target

---------------------------------------*/

Target::Target(void) :
	targetLength(0),
	dataOffset(0),
	dataSize(0) {}

Target::Target(	const QString& target_name,
				const quint32& target_length):
	targetName(target_name),
	targetLength(target_length),
	dataOffset(0),
	dataSize(0){}

Target::Target(const Target& original):
	targetName(original.targetName),
	targetLength(original.targetLength),
	dataOffset(original.dataOffset),
	dataSize(original.dataSize){}

Target& Target::operator =(const Target& original)
{
	targetName=original.targetName;
	targetLength=original.targetLength;
	dataOffset=original.dataOffset;
	dataSize=original.dataSize;
	return *this;
}

void Target::putSerialized(QDataStream& out)
{
	out << targetName
		<< targetLength
		<< dataOffset
		<< dataSize;
}

void Target::getSerialized(QDataStream& in)
{
	in >> targetName
		>> targetLength
		>> dataOffset
		>> dataSize;
}

/*---------------------------------------

		namespace DesktopTrack
		namespace VPlotFile
		class TargetLess

---------------------------------------*/

TargetLess::TargetLess(void){}

bool TargetLess::operator()(const Target& a, const Target& b)
{
	return a.targetName < b.targetName;
}


/*---------------------------------------

		namespace DesktopTrack
		namespace VPlotFile
		class FileReader

---------------------------------------*/


FileReader::FileReader(void){}

bool FileReader::setFile(const QString& file_path)
{
	targetList.clear();
	targetMap.clear();
	if(file.isOpen()){
		file.close();	
	}
	file.setFileName(file_path);
	file.open(QIODevice::ReadOnly);
	if(!file.isOpen()){
		return false;
	}
	QDataStream in(&file);

	//�w�b�_�[��ǂݍ����
	header.getSerialized(in);
	//�w�b�_�[����
	if(!header.isCorrectFile()){
		return false;
	}

	QByteArray data;
	QBuffer buffer;
	int i;

	//target list���擾
	file.seek(header.targetListOffset);
	data=file.read(header.targetListDataSize);
	buffer.setBuffer(&data);
	buffer.open(QIODevice::ReadOnly);
	in.setDevice(&buffer);
	for(i=0; i<header.targetListDataCount; i++){
		Target temp;
		temp.getSerialized(in);
		targetList.push_back(temp);
	}
	for(i=0; i<targetList.size(); i++){
		QString targetName=targetList[i].targetName;
		targetMap[targetName]=i;
	}
	buffer.close();
	file.close();
	return true;
}

bool FileReader::releaseFile(void)
{
	if(file.isOpen()){
		file.close();
		return true;
	}
	else{
		return false;
	}
}

bool FileReader::unsetFile(void)
{
	Header header;
	this->header=header;
	targetList.clear();
	targetMap.clear();
	file.close();
	return true;
}

const Header& FileReader::getBasicTrackInfo(void) const
{
	return header; 
}

const QList<Target>& FileReader::getTargetList(void) const
{
	return targetList;
}

bool FileReader::targetContains(const QString& target_name)
{
	if(targetMap.contains(target_name)){
		return true;
	}
	else{
		return false;
	}
}

bool FileReader::setBasicTrackConf(const Header& conf)
{
	if(file.isOpen()){
		file.close();
	}
	file.open(QIODevice::Append);
	if(!file.isOpen()){
		return false;
	}

	header.rowHeight=conf.rowHeight;
	header.fontSize=conf.fontSize;
	header.fgColor=conf.fgColor;
	header.bgColor=conf.bgColor;
	header.anColor=conf.anColor;
	file.seek(0);
	QDataStream out;
	out.setDevice(&file);
	header.putSerialized(out);
	file.close();
	return true;

}

bool FileReader::getData(
	const QString& target_name,
	std::vector<std::vector<quint8> >& data_to)
{

	if (!targetMap.contains(target_name)) {
		return false;
	}
	Target& target = targetList[targetMap[target_name]];

	if (file.isOpen()) {
		file.close();
	}
	file.open(QIODevice::ReadOnly);
	if (!file.isOpen()) {
		return false;
	}

	quint64 offset = 0;
	quint64 dataCount = target.targetLength;
	qint64 dataSize = header.stepNum*dataCount;

	//�i�[��̃T�C�Y��ύX
	data_to.clear();
	data_to.resize(header.stepNum, std::vector<quint8>(dataCount, 0));

	//�t�@�C�����e���o�b�t�@�[�ɓǂݍ���
	quint64 x = 0;	//���ʒu
	quint32 y = 0;	//�c�ʒu
	file.seek(target.dataOffset + offset);

	while (dataSize>0) {
		qint64 sizeTobeRead = BufferSizeMax < dataSize ? BufferSizeMax : dataSize;
		QByteArray data = file.read(sizeTobeRead);
		dataSize -= data.size();
		for (int i = 0; i < data.size(); i++) {
			data_to[y][x] = data[i];
			y++;
			if (y >= header.stepNum) {
				y = 0;
				x++;
				if (x >= dataCount) {
					break;	//for (int i = 0; i < data.size(); i++)
				}
			}
		}
		//�p�ӂ����f�[�^�X�y�[�X��S�Ė��߂�
		if (y >= header.stepNum&&x >= dataCount) {
			//�ǂݏo���ׂ��f�[�^�͂��͂△��
			if (dataSize == 0) {
				//�f�[�^�͖����͂�
				return true;
			}
			else {
				//�f�[�^���c���Ă���̂ł���Ή�������������
				return false;
			}
		}
	}

	return false;

}

bool FileReader::getData(
	const QString& target_name,
	const quint64& start,
	const quint64& end,
	std::vector<std::vector<quint8> >& data_to)
{
	if(start>end){
		return false;
	}
	if(!targetMap.contains(target_name)){
		return false;
	}
	Target& target=targetList[targetMap[target_name]];
	if(end>target.targetLength){
		return false;
	}

	if(file.isOpen()){
		file.close();	
	}
	file.open(QIODevice::ReadOnly);
	if(!file.isOpen()){
		return false;
	}

	quint64 offset= header.stepNum*(start-1);
	quint64 dataCount=end-start+1;
	quint64 dataSize= header.stepNum*dataCount;

	//�i�[��̃T�C�Y��ύX
	data_to.clear();
	data_to.resize(header.stepNum, std::vector<quint8>(dataCount, 0));

	//�t�@�C�����e���o�b�t�@�[�ɓǂݍ���
	int x = 0;	//���ʒu
	int y = 0;	//�c�ʒu
	file.seek(target.dataOffset + offset);
	quint64 dataRead = 0;
	while (dataSize>0) {
		quint64 sizeTobeRead = BufferSizeMax < dataSize ? BufferSizeMax : dataSize;
		QByteArray data = file.read(sizeTobeRead);
		dataSize -= data.size();
		for (int i = 0; i < data.size(); i++) {
			data_to[y][x] = data[i];
			y++;
			if (y >= header.stepNum) {
				y = 0;
				x++;
				if (x >= dataCount) {
					x = 0;
					break;	//for (int i = 0; i < data.size(); i++)
				}
			}
		}
		if (y == 0 && x == 0 && dataSize == 0) {
			return true;
		}
	}

	return false;

}

