#include "BasicTracks.h"

#ifdef Q_OS_WIN32
#include <io.h>
#include <fcntl.h>
#endif

using namespace DesktopTrack;

//�R���X�g���N�^
BasicTracks::BasicTracks(void){}


bool BasicTracks::printTrackLayer(void)
{
	if(CGIParam.track_layer==""){
		return printTrackList();
	}
	else if(CGIParam.track_layer=="description"){
		return printDescFile();
	}
	else if(CGIParam.track_layer=="image"){
		printImage();
	}
	else if(CGIParam.track_layer=="index"){
		printIndexImage();
	}
	else if(CGIParam.track_layer=="operation"){
		printOperation();
	}
	else if(CGIParam.track_layer=="index_operation"){
		printIndexOperation();
	}
	return true;

}

bool BasicTracks::printDescFile(void)
{
	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(CGIParam.species)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.species)){
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(CGIParam.revision)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.revision)){
		return false;
	}
	//BinSeq�̊m�F
	QString binseqFileName(BinSeqFileTemp.arg(CGIParam.species).arg(CGIParam.revision));
	if(!RevisionDir.exists(binseqFileName)){
		return false;
	}
	BinSeq::FileReader reader;
	if(!reader.setFile(RevisionDir.filePath(binseqFileName))){
		return false;
	}

	const BinSeq::Header& header=reader.getTrackConfig();

	if(header.species!=CGIParam.species){
		return false;
	}
	if(header.revision!=CGIParam.revision){
		return false;
	}

	if(CGIParam.track_name==Overview){

		#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
		#endif
		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: text/javascript\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}

		//�g���b�N�R���t�B�O���[�V�����y�[���̓��\�[�X���Ɋi�[���Ă���
		QFile resource(":/browser/OverviewTrackConfigurationPane.js");
		resource.open(QIODevice::ReadOnly);
		//�I���W�i����JavaScript��S���ǂݏo��
		QString document(QString::fromUtf8(resource.readAll().data()));

		QString anotherParams;
		for(int i=0; i<CGIParam.anotherParam.size(); i++){
			anotherParams
				.append(",\n\t\t'")
				.append(CGIParam.anotherParam[i].first)
				.append("':'")
				.append(CGIParam.anotherParam[i].second)
				.append("'");
		}

		out << document
			.replace(QString("SPECIES"), header.species)
			.replace(QString("REVISION"), header.revision)
			.replace(QString("TRACK_URL"), CGIParam.address)
			.replace(QString("FG_COLOR"), header.ovFgColor.name())
			.replace(QString("BG_COLOR"), header.ovBgColor.name())
			.replace(QString("MARK_COLOR"), header.ovMarkColor.name())
			.replace(QString("ANOTHER_PARAM"), anotherParams);

		//out << "CreateTrack(" << endl
		//	<< "\t{" << endl
		//	<< "\t\t'track_name':'overview'," << endl
		//	<< "\t\t'accept_species':{" << endl
		//	<< "\t\t\t'species':'" << header.species << "'," << endl
		//	<< "\t\t\t'revision':'" << header.revision << "'" << endl
		//	<< "\t\t}," << endl
		//	<< "\t\t'track_url':'" << CGIParam.address << "'," << endl
		//	<< "\t\t'track_arguments':{" << endl
		//	<< "\t\t\t'track_name':'overview'" << endl
		//	<< "\t\t}," << endl
		//	//<< "\t\t'option_arguments':{" << endl
		//	//<< "\t\t\t'overview_foreground_color':'color'," << endl
		//	//<< "\t\t\t'overview_background_color':'color'," << endl
		//	//<< "\t\t\t'overview_dispregion_color':'color'," << endl
		//	//<< "\t\t\t'overview_row_height':'unsigned integer'" << endl
		//	//<< "\t\t}," << endl
		//	<< "\t\t'image':{" << endl
		//	<< "\t\t\t'layer_arguments':{" << endl
		//	<< "\t\t\t\t'track_layer':'image'" << endl
		//	<< "\t\t\t}" << endl
		//	<< "\t\t}," << endl
		//	<< "\t\t'index':{" << endl
		//	<< "\t\t\t'layer_arguments':{" << endl
		//	<< "\t\t\t\t'track_layer':'index'" << endl
		//	<< "\t\t\t}" << endl
		//	<< "\t\t},"
		//	<< "\t\t''config_pane':'true'" << endl
  //          << "\t\tANOTHER_PARAM" << endl
		//	<< "\t}" << endl;

		//for(int i=0; i<CGIParam.anotherParam.size(); i++){
		//	out	<< "," << endl
		//		<< "\t\t'" << CGIParam.anotherParam[i].first << "':'" << CGIParam.anotherParam[i].second << "'";
		//}
		//out	<< endl
		//	<< "\t}" << endl
		//	<< ");" << endl;

		out.flush();

	}


	else if(CGIParam.track_name==Ruler){

		#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
		#endif
		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: text/javascript\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}

		//�g���b�N�R���t�B�O���[�V�����y�[���̓��\�[�X���Ɋi�[���Ă���
		QFile resource(":/browser/RulerTrackConfigurationPane.js");
		resource.open(QIODevice::ReadOnly);
		//�I���W�i����JavaScript��S���ǂݏo��
		QString document(QString::fromUtf8(resource.readAll().data()));

		QString anotherParams;
		for(int i=0; i<CGIParam.anotherParam.size(); i++){
			anotherParams
				.append(",\n\t\t'")
				.append(CGIParam.anotherParam[i].first)
				.append("':'")
				.append(CGIParam.anotherParam[i].second)
				.append("'");
		}

		out << document
			.replace(QString("SPECIES"), header.species)
			.replace(QString("REVISION"), header.revision)
			.replace(QString("TRACK_URL"), CGIParam.address)
			.replace(QString("FG_COLOR"), header.rlFgColor.name())
			.replace(QString("BG_COLOR"), header.rlBgColor.name())
			.replace(QString("ANOTHER_PARAM"), anotherParams);


		//out << "CreateTrack(" << endl
			//<< "\t{" << endl
			//<< "\t\t'track_name':'ruler'," << endl
			//<< "\t\t'accept_species':{" << endl
			//<< "\t\t\t'species':'" << header.species << "'," << endl
			//<< "\t\t\t'revision':'" << header.revision << "'" << endl
			//<< "\t\t}," << endl
			//<< "\t\t'track_url':'" << CGIParam.address << "'," << endl
			//<< "\t\t'track_arguments':{" << endl
			//<< "\t\t\t'track_name':'ruler'" << endl
			//<< "\t\t}," << endl
			//<< "\t\t'option_arguments':{" << endl
			//<< "\t\t\t'ruler_foreground_color':'color'," << endl
			//<< "\t\t\t'ruler_background_color':'color'," << endl
			//<< "\t\t\t'ruler_row_height':'unsigned integer'" << endl
			//<< "\t\t}," << endl
			//<< "\t\t'image':{" << endl
			//<< "\t\t\t'layer_arguments':{" << endl
			//<< "\t\t\t\t'track_layer':'image'" << endl
			//<< "\t\t\t}" << endl
			//<< "\t\t}," << endl
			//<< "\t\t'index':{" << endl
			//<< "\t\t\t'layer_arguments':{" << endl
			//<< "\t\t\t\t'track_layer':'index'" << endl
			//<< "\t\t\t}" << endl
			//<< "\t\t}";
		//for(int i=0; i<CGIParam.anotherParam.size(); i++){
		//	out	<< "," << endl
		//		<< "\t\t'" << CGIParam.anotherParam[i].first << "':'" << CGIParam.anotherParam[i].second << "'";
		//}
		//out	<< endl
		//	<< "\t}" << endl
		//	<< ");" << endl;

		out.flush();

	}
	else if(CGIParam.track_name==Basecolor){

		#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
		#endif
		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: text/javascript\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}

		//�g���b�N�R���t�B�O���[�V�����y�[���̓��\�[�X���Ɋi�[���Ă���
		QFile resource(":/browser/BasecolorTrackConfigurationPane.js");
		resource.open(QIODevice::ReadOnly);
		//�I���W�i����JavaScript��S���ǂݏo��
		QString document(QString::fromUtf8(resource.readAll().data()));

		QString anotherParams;
		for(int i=0; i<CGIParam.anotherParam.size(); i++){
			anotherParams
				.append(",\n\t\t'")
				.append(CGIParam.anotherParam[i].first)
				.append("':'")
				.append(CGIParam.anotherParam[i].second)
				.append("'");
		}

		out << document
			.replace(QString("SPECIES"), header.species)
			.replace(QString("REVISION"), header.revision)
			.replace(QString("TRACK_URL"), CGIParam.address)
			.replace(QString("COLOR_FOR_A"), header.bgColorForA.name())
			.replace(QString("COLOR_FOR_C"), header.bgColorForC.name())
			.replace(QString("COLOR_FOR_G"), header.bgColorForG.name())
			.replace(QString("COLOR_FOR_T"), header.bgColorForT.name())
			.replace(QString("COLOR_FOR_N"), header.bgColorForN.name())
			.replace(QString("ANOTHER_PARAM"), anotherParams);

		//out << "CreateTrack(" << endl
			//<< "\t{" << endl
			//<< "\t\t'track_name':'basecolor'," << endl
			//<< "\t\t'accept_species':{" << endl
			//<< "\t\t\t'species':'" << header.species << "'," << endl
			//<< "\t\t\t'revision':'" << header.revision << "'" << endl
			//<< "\t\t}," << endl
			//<< "\t\t'track_url':'" << CGIParam.address << "'," << endl
			//<< "\t\t'track_arguments':{" << endl
			//<< "\t\t\t'track_name':'basecolor'" << endl
			//<< "\t\t}," << endl
			//<< "\t\t'option_arguments':{" << endl
			//<< "\t\t\t'basecolor_for_a':'color'," << endl
			//<< "\t\t\t'basecolor_for_c':'color'," << endl
			//<< "\t\t\t'basecolor_for_g':'color'," << endl
			//<< "\t\t\t'basecolor_for_t':'color'," << endl
			//<< "\t\t\t'basecolor_for_n':'color'," << endl
			//<< "\t\t\t'basecolor_row_height':'unsigned integer'" << endl
			//<< "\t\t}," << endl
			//<< "\t\t'image':{" << endl
			//<< "\t\t\t'layer_arguments':{" << endl
			//<< "\t\t\t\t'track_layer':'image'" << endl
			//<< "\t\t\t}" << endl
			//<< "\t\t}," << endl
			//<< "\t\t'index':{" << endl
			//<< "\t\t\t'layer_arguments':{" << endl
			//<< "\t\t\t\t'track_layer':'index'" << endl
			//<< "\t\t\t}" << endl
			//<< "\t\t}";
		//for(int i=0; i<CGIParam.anotherParam.size(); i++){
			//out	<< "," << endl
				//<< "\t\t'" << CGIParam.anotherParam[i].first << "':'" << CGIParam.anotherParam[i].second << "'";
		//}
		//out	<< endl
			//<< "\t}" << endl
			//<< ");" << endl;
		out.flush();

	}
	else{
		return false;
	}
	return true;

}

bool BasicTracks::printTrackList(void)
{

	#ifdef Q_OS_WIN32
	_setmode( _fileno( stdout ), _O_BINARY );
	#endif
	QFile file;
	file.open(stdout, QIODevice::WriteOnly);
	QTextStream out(&file);

	QDomDocument doc(TrackListTag);
	QDomElement root = doc.createElement(TrackListTag);
	doc.appendChild(root);

	QDir revisionDir(QApplication::applicationDirPath());
	if(!revisionDir.exists(RevisionsDirName)){
		return false;
	}
	if(!revisionDir.cd(RevisionsDirName)){
		return false;
	}
	QStringList speciesList;
	if(CGIParam.species.size()!=0){
		speciesList.push_back(CGIParam.species);
	}
	else{
		speciesList=revisionDir.entryList(QDir::Dirs|QDir::NoDotAndDotDot, QDir::Name);
	}
	for(int i=0; i<speciesList.size(); i++){
		QDir speciesDir(revisionDir);
		QString& species=speciesList[i];
		if(!speciesDir.exists(species)){
			continue;
		}
		if(!speciesDir.cd(species)){
			continue;
		}
		QStringList revisionsList;
		if(CGIParam.revision.size()!=0){
			revisionsList.push_back(CGIParam.revision);
		}
		else{
			revisionsList=speciesDir.entryList(QDir::Dirs|QDir::NoDotAndDotDot, QDir::Name);
		}
		for(int j=0; j<revisionsList.size(); j++){
			QDir revisionsDir(speciesDir);
			QString& revision=revisionsList[j];
			if(!revisionsDir.exists(revision)){
				continue;
			}
			if(!revisionsDir.cd(revision)){
				continue;
			}
			//BinSeq�̊m�F
			QString binseqFileName(BinSeqFileTemp.arg(speciesList[i]).arg(revisionsList[j]));
			if(!revisionsDir.exists(binseqFileName)){
				continue;
			}
			BinSeq::FileReader r;
			if(!r.setFile(revisionsDir.filePath(binseqFileName))){
				continue;
			}
			BinSeq::Header header=r.getTrackConfig();
			//species�̊m�F
			if(header.species!=species){
				continue;
			}
			//revision�̊m�F
			if(header.revision!=revision){
				continue;
			}

			QDomElement track_tag = doc.createElement(TrackTag);
			track_tag.setAttribute(SpeciesAttr, species);
			track_tag.setAttribute(RevisionAttr, revision);
			track_tag.setAttribute(NameAttr, Overview);
			track_tag.setAttribute(ProgramAttr, CGIParam.address);
			root.appendChild(track_tag);

			track_tag = doc.createElement(TrackTag);
			track_tag.setAttribute(SpeciesAttr, species);
			track_tag.setAttribute(RevisionAttr, revision);
			track_tag.setAttribute(NameAttr, Ruler);
			track_tag.setAttribute(ProgramAttr, CGIParam.address);
			root.appendChild(track_tag);

			track_tag = doc.createElement(TrackTag);
			track_tag.setAttribute(SpeciesAttr, species);
			track_tag.setAttribute(RevisionAttr, revision);
			track_tag.setAttribute(NameAttr, Basecolor);
			track_tag.setAttribute(ProgramAttr, CGIParam.address);
			root.appendChild(track_tag);


		}

	}

	if(CGIParam.is_cgi){
		out << "Content-type: text/xml\n"
			<< "Pragma: no-cache\n\n";
		out.flush();
	}

	out << doc.toString();

	return true;

}

bool BasicTracks::printImage(void)
{
	if(CGIParam.track_name=="overview"){

		QImage image;
		if(!createOverviewImage(image)){
			createErrorImage(image);	
		}
		//�C���[�W�̏����o��
		#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
		#endif

		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: image/png\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}
		QImageWriter writer(&file, "png");
		if(!writer.canWrite()){
			return false;
		}
		if(!writer.write(image)){
			QString errorString = writer.errorString();
			return false;
		}

		file.flush();
		file.close();
		return true;

	}
	else if(CGIParam.track_name=="ruler"){

		QImage image;
		if(!createRulerImage(image)){
			createErrorImage(image);	
		}
		//�C���[�W�̏����o��
		#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
		#endif

		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: image/png\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}
		QImageWriter writer(&file, "png");
		if(!writer.canWrite()){
			return false;
		}
		if(!writer.write(image)){
			QString errorString = writer.errorString();
			return false;
		}

		file.flush();
		file.close();
		return true;

	}
	else if(CGIParam.track_name=="basecolor"){

		QImage image;
		if(!createBaseColorImage(image)){
			createErrorImage(image);	
		}
		//�C���[�W�̏����o��
		#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
		#endif

		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: image/png\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}
		QImageWriter writer(&file, "png");
		if(!writer.canWrite()){
			return false;
		}
		if(!writer.write(image)){
			QString errorString = writer.errorString();
			return false;
		}

		file.flush();
		file.close();
		return true;

	}
	else{
		return false;
	}
}



bool BasicTracks::printIndexImage(void)
{
	if(CGIParam.track_name=="overview"){

		QImage image;
		if(!createOverviewIndexImage(image)){
			createErrorIndexImage(image);	
		}
		//�C���[�W�̏����o��
		#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
		#endif

		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: image/png\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}
		QImageWriter writer(&file, "png");
		if(!writer.canWrite()){
			return false;
		}
		if(!writer.write(image)){
			QString errorString = writer.errorString();
			return false;
		}

		file.flush();
		file.close();
		return true;

	}
	else if(CGIParam.track_name=="ruler"){

		QImage image;
		if(!createRulerIndexImage(image)){
			createErrorIndexImage(image);	
		}
		//�C���[�W�̏����o��
		#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
		#endif

		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: image/png\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}
		QImageWriter writer(&file, "png");
		if(!writer.canWrite()){
			return false;
		}
		if(!writer.write(image)){
			QString errorString = writer.errorString();
			return false;
		}

		file.flush();
		file.close();
		return true;

	}
	else if(CGIParam.track_name=="basecolor"){

		QImage image;
		if(!createBaseColorIndexImage(image)){
			createErrorIndexImage(image);	
		}
		//�C���[�W�̏����o��
		#ifdef Q_OS_WIN32
		_setmode( _fileno( stdout ), _O_BINARY );
		#endif

		QFile file;
		file.open(stdout, QIODevice::WriteOnly);
		QTextStream out(&file);
		if(CGIParam.is_cgi){
			out << "Content-type: image/png\n"
				<< "Pragma: no-cache\n\n";
			out.flush();
		}
		QImageWriter writer(&file, "png");
		if(!writer.canWrite()){
			return false;
		}
		if(!writer.write(image)){
			QString errorString = writer.errorString();
			return false;
		}

		file.flush();
		file.close();
		return true;

	}
	else{
		return false;
	}
}

bool BasicTracks::printOperation(void)
{

	return true;
}

bool BasicTracks::printIndexOperation(void)
{

	return true;
}

void BasicTracks::createErrorImage(QImage& imageTo)
{

	QImage image(CGIParam.pixel_width, RowHeight, QImage::Format_RGB32);
	QPainter painter(&image);
	painter.setPen(Qt::NoPen);
	painter.setBrush(BgColor);
	painter.drawRect(image.rect());
	painter.setBrush(Qt::NoBrush);
	painter.setPen(FgColor);
	QFont font(QApplication::font());
	font.setPointSize(5);
	painter.setFont(font);
	painter.drawText(image.rect(), Qt::AlignCenter, "Error: Couldn't draw image.");

}

void BasicTracks::createErrorIndexImage(QImage& imageTo)
{

	QImage image(IndexWidth, RowHeight, QImage::Format_RGB32);
	QPainter painter(&image);
	painter.setPen(Qt::NoPen);
	painter.setBrush(BgColor);
	painter.drawRect(image.rect());
	painter.setBrush(Qt::NoBrush);
	painter.setPen(FgColor);
	QFont font(QApplication::font());
	font.setPointSize(5);
	painter.setFont(font);
	painter.drawText(image.rect(), Qt::AlignCenter, "Error: Couldn't draw image.");

}

bool BasicTracks::createOverviewImage(QImage& imageTo)
{

	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(CGIParam.species)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.species)){
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(CGIParam.revision)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.revision)){
		return false;
	}
	//BinSeq�̊m�F
	QString binseqFileName(BinSeqFileTemp.arg(CGIParam.species).arg(CGIParam.revision));
	if(!RevisionDir.exists(binseqFileName)){
		return false;
	}
	BinSeq::FileReader reader;
	if(!reader.setFile(RevisionDir.filePath(binseqFileName))){
		return false;
	}
	//�͈͊m�F
	quint64 targetSize;
	if(!reader.targetExists(CGIParam.target_name, targetSize)){
		return false;
	}
	if(CGIParam.start_from<1||CGIParam.start_from>targetSize){
		return false;
	}
	if(CGIParam.end_to<1||CGIParam.end_to>targetSize){
		return false;
	}	
	//config�擾
	header=reader.getTrackConfig();

	//�F�ύX�̗v��������Ή�����
	if(CGIParam.foreground_color!=""){
		QByteArray colorArray=CGIParam.foreground_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.ovFgColor.setNamedColor(colorString);
		}
		#else
		header.ovFgColor.setNamedColor(colorString);
		#endif
	}

	if(CGIParam.background_color!=""){
		//header.ovBgColor.setNamedColor(CGIParam.background_color);
		QByteArray colorArray=CGIParam.background_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.ovBgColor.setNamedColor(colorString);
		}
		#else
		header.ovBgColor.setNamedColor(colorString);
		#endif
	}

	if(CGIParam.dispregion_color!=""){
		//header.ovMarkColor.setNamedColor(CGIParam.dispregion_color);
		QByteArray colorArray=CGIParam.dispregion_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.ovMarkColor.setNamedColor(colorString);
		}
		#else
		header.ovMarkColor.setNamedColor(colorString);
		#endif
	}

	if(CGIParam.row_height>=20){
		header.ovRowHeight = CGIParam.row_height;
	}

	//image����
	if(CGIParam.pixel_width<1){
		return false;
	}

	//�C���[�W�̗p��
	int image_height = header.ovRowHeight;
	int image_width = CGIParam.pixel_width;
	QImage image(image_width, image_height, QImage::Format_RGB32);
	paintBackGround(header.ovBgColor, &image);

	//�\���̈�̃}�[�N
	drawDisplayRegion(CGIParam.start_from, CGIParam.end_to, targetSize, header.ovMarkColor, &image);

	if(CGIParam.start_from<CGIParam.end_to){
		drawGradLine(1, targetSize, header.ovFgColor, &image);
	}
	else{
		drawGradLine(targetSize, 1, header.ovFgColor, &image);
	}

	imageTo=image;

	return true;

}

bool BasicTracks::createRulerImage(QImage& imageTo)
{
	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(CGIParam.species)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.species)){
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(CGIParam.revision)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.revision)){
		return false;
	}
	//BinSeq�̊m�F
	QString binseqFileName(BinSeqFileTemp.arg(CGIParam.species).arg(CGIParam.revision));
	if(!RevisionDir.exists(binseqFileName)){
		return false;
	}
	BinSeq::FileReader reader;
	if(!reader.setFile(RevisionDir.filePath(binseqFileName))){
		return false;
	}
	//�͈͊m�F
	quint64 targetSize;
	if(!reader.targetExists(CGIParam.target_name, targetSize)){
		return false;
	}
	if(CGIParam.start_from<1||CGIParam.start_from>targetSize){
		return false;
	}
	if(CGIParam.end_to<1||CGIParam.end_to>targetSize){
		return false;
	}	
	//config�擾
	header=reader.getTrackConfig();

	//�F�ύX�̗v��������Ή�����
	if(CGIParam.foreground_color!=""){
        QByteArray colorArray=CGIParam.foreground_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.rlFgColor.setNamedColor(colorString);
		}
        #else
		header.rlFgColor.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.background_color!=""){
		QByteArray colorArray=CGIParam.background_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.rlBgColor.setNamedColor(colorString);
		}
        #else
		header.rlBgColor.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.row_height>=20){
		header.rlRowHeight = CGIParam.row_height;
	}

	//image����
	if(CGIParam.pixel_width<1){
		return false;
	}

	//�C���[�W�̗p��
	int image_height = header.rlRowHeight;
	int image_width = CGIParam.pixel_width;
	QImage image(image_width, image_height, QImage::Format_RGB32);
	paintBackGround(header.rlBgColor, &image);

	//
	drawGradLine(CGIParam.start_from, CGIParam.end_to, header.rlFgColor, &image);

	imageTo=image;
	return true;

}

bool BasicTracks::createBaseColorImage(QImage& imageTo)
{

	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(CGIParam.species)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.species)){
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(CGIParam.revision)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.revision)){
		return false;
	}
	//BinSeq�̊m�F
	QString binseqFileName(BinSeqFileTemp.arg(CGIParam.species).arg(CGIParam.revision));
	if(!RevisionDir.exists(binseqFileName)){
		return false;
	}
	BinSeq::FileReader reader;
	if(!reader.setFile(RevisionDir.filePath(binseqFileName))){
		return false;
	}
	quint64 targetSize;
	if(!reader.targetExists(CGIParam.target_name, targetSize)){
		return false;
	}
	if(CGIParam.start_from<1||CGIParam.start_from>targetSize){
		return false;
	}
	if(CGIParam.end_to<1||CGIParam.end_to>targetSize){
		return false;
	}	

	//config�擾
	header=reader.getTrackConfig();

	//�F�ύX�̗v��������Ή�����			
	if(CGIParam.color_for_a!=""){
		QByteArray colorArray=CGIParam.color_for_a.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForA.setNamedColor(colorString);
		}
        #else
		header.bgColorForA.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.color_for_c!=""){
		QByteArray colorArray=CGIParam.color_for_c.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForC.setNamedColor(colorString);
		}
        #else
		header.bgColorForC.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.color_for_g!=""){
		QByteArray colorArray=CGIParam.color_for_g.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForG.setNamedColor(colorString);
		}
        #else
		header.bgColorForG.setNamedColor(colorString);
        #endif
	}		
	if(CGIParam.color_for_t!=""){
		QByteArray colorArray=CGIParam.color_for_t.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForT.setNamedColor(colorString);
		}
        #else
		header.bgColorForT.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.color_for_n!=""){
		QByteArray colorArray=CGIParam.color_for_n.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForN.setNamedColor(colorString);
		}
        #else
		header.bgColorForN.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.row_height>=20){
		header.bgRowHeight=CGIParam.row_height;
	}

	color_for_anti_a.setRgb(255-header.bgColorForA.red(), 255-header.bgColorForA.green(), 255-header.bgColorForA.blue());
	color_for_anti_c.setRgb(255-header.bgColorForC.red(), 255-header.bgColorForC.green(), 255-header.bgColorForC.blue());
	color_for_anti_g.setRgb(255-header.bgColorForG.red(), 255-header.bgColorForG.green(), 255-header.bgColorForG.blue());
	color_for_anti_t.setRgb(255-header.bgColorForT.red(), 255-header.bgColorForT.green(), 255-header.bgColorForT.blue());
	color_for_anti_n.setRgb(255-header.bgColorForN.red(), 255-header.bgColorForN.green(), 255-header.bgColorForN.blue());

	if(CGIParam.pixel_width<1){
		return false;
	}

	//�C���[�W�̗p��
	int image_height = header.bgRowHeight;
	int image_width = CGIParam.pixel_width;

	QImage image(image_width, image_height, QImage::Format_RGB32);
	paintBackGround(Qt::white, &image);

	//�z��t�@�C�����I�[�v��
	if(!reader.setFile(RevisionDir.filePath(binseqFileName))){
		return false;
	}

	//�z��̎擾
	QByteArray seq;
	quint32 start = CGIParam.start_from<CGIParam.end_to?CGIParam.start_from:CGIParam.end_to;
	quint32 end = CGIParam.start_from<CGIParam.end_to?CGIParam.end_to:CGIParam.start_from;
	if(!reader.getSeq(CGIParam.target_name, start, end, seq)){
		return false;
	}

	QFont font(QApplication::font());
	int fontPoint;

	for(fontPoint=header.bgRowHeight; fontPoint>=1; fontPoint--){
		font.setPointSize(fontPoint);
		QFontMetrics tempFm(font);
		if(tempFm.height()<=header.bgRowHeight*3/4){
			break;
		}
	}

	QFontMetrics fm(font);
	int max_width = qMax(fm.width("A"), fm.width("C"));
	max_width = qMax(max_width, fm.width("G"));
	max_width = qMax(max_width, fm.width("T"));
	max_width = qMax(max_width, fm.width("N"));

	if(image_width/seq.size()>max_width){
		for(int i=0; i<seq.size(); i++){
			int start_pos = (i*image_width/seq.size());
			int width = ((i+1)*image_width/seq.size()-start_pos);
			if(CGIParam.start_from<=CGIParam.end_to){
				drawBaseChar(start_pos, width, seq[i], 1, font, &image);
			}
			else{
				drawBaseChar(start_pos, width, seq[seq.size()-i-1], -1, font, &image);
			}

		}
	}
	else{
		//�F�̏�������
		for(int i=0; i<image_width; i++){
			int base_pos;
			if(CGIParam.start_from<=CGIParam.end_to){
				base_pos = (int)(((qint64)i*(qint64)seq.size())/(qint64)image_width);
				drawVarticalLine(i, seq[base_pos], 1, &image);
			}
			else{
				base_pos = seq.size()-(int)(((qint64)i*(qint64)seq.size())/(qint64)image_width-1);
				drawVarticalLine(i, seq[base_pos], -1, &image);
			}
		}
	}

	imageTo=image;
	return true;

}

bool BasicTracks::createOverviewIndexImage(QImage& imageTo)
{
	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(CGIParam.species)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.species)){
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(CGIParam.revision)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.revision)){
		return false;
	}
	//BinSeq�̊m�F
	QString binseqFileName(BinSeqFileTemp.arg(CGIParam.species).arg(CGIParam.revision));
	if(!RevisionDir.exists(binseqFileName)){
		return false;
	}
	BinSeq::FileReader reader;
	if(!reader.setFile(RevisionDir.filePath(binseqFileName))){
		return false;
	}
	quint64 targetSize;
	if(!reader.targetExists(CGIParam.target_name, targetSize)){
		return false;
	}
	if(CGIParam.start_from<1||CGIParam.start_from>targetSize){
		return false;
	}
	if(CGIParam.end_to<1||CGIParam.end_to>targetSize){
		return false;
	}	
	//config�擾
	header=reader.getTrackConfig();

	//�F�ύX�̗v��������Ή�����
	if(CGIParam.foreground_color!=""){
        QByteArray colorArray=CGIParam.foreground_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.ovFgColor.setNamedColor(colorString);
		}
		#else
		header.ovFgColor.setNamedColor(colorString);
		#endif
	}
	if(CGIParam.background_color!=""){
		QByteArray colorArray=CGIParam.background_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.ovBgColor.setNamedColor(colorString);
		}
		#else
		header.ovBgColor.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.dispregion_color!=""){
		QByteArray colorArray=CGIParam.dispregion_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.ovMarkColor.setNamedColor(colorString);
		}
		#else
		header.ovMarkColor.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.row_height>=20){
		header.ovRowHeight = CGIParam.row_height;
	}

	//image����
	if(CGIParam.pixel_width<1){
		return false;
	}

	//�C���[�W�̗p��
	QImage image(IndexWidth, header.ovRowHeight, QImage::Format_RGB32);
	paintBackGround(header.ovBgColor, &image);

	QPainter painter(&image);
	painter.setPen(header.ovFgColor);
	painter.setBrush(Qt::NoBrush);

	QFont font(QApplication::font());
	int fontPoint;

	for(fontPoint=header.ovRowHeight; fontPoint>=1; fontPoint--){
		font.setPointSize(fontPoint);
		QFontMetrics tempFm(font);
		if(tempFm.height()<=header.ovRowHeight*3/4){
			break;
		}
	}

	painter.setFont(font);
	painter.drawText(0, 0, image.width(), image.height(), Qt::AlignCenter, "Overview");

	imageTo=image;

	return true;

}

bool BasicTracks::createRulerIndexImage(QImage& imageTo)
{
	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(CGIParam.species)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.species)){
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(CGIParam.revision)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.revision)){
		return false;
	}
	//BinSeq�̊m�F
	QString binseqFileName(BinSeqFileTemp.arg(CGIParam.species).arg(CGIParam.revision));
	if(!RevisionDir.exists(binseqFileName)){
		return false;
	}
	BinSeq::FileReader reader;
	if(!reader.setFile(RevisionDir.filePath(binseqFileName))){
		return false;
	}
	quint64 targetSize;
	if(!reader.targetExists(CGIParam.target_name, targetSize)){
		return false;
	}
	if(CGIParam.start_from<1||CGIParam.start_from>targetSize){
		return false;
	}
	if(CGIParam.end_to<1||CGIParam.end_to>targetSize){
		return false;
	}	
	//config�擾
	header=reader.getTrackConfig();

	//�F�ύX�̗v��������Ή�����
	if(CGIParam.foreground_color!=""){
        QByteArray colorArray=CGIParam.foreground_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.rlFgColor.setNamedColor(colorString);
		}
        #else
		header.rlFgColor.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.background_color!=""){
		QByteArray colorArray=CGIParam.background_color.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.rlBgColor.setNamedColor(colorString);
		}
		#else
		header.rlBgColor.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.row_height>=5){
		header.rlRowHeight = CGIParam.row_height;
	}


	//image����
	if(CGIParam.pixel_width<1){
		return false;
	}

	//�C���[�W�̗p��
	QImage image(IndexWidth, header.rlRowHeight, QImage::Format_RGB32);
	paintBackGround(header.rlBgColor, &image);

	QPainter painter(&image);
	painter.setPen(header.rlFgColor);
	painter.setBrush(Qt::NoBrush);

	QFont font(QApplication::font());
	int fontPoint;

	for(fontPoint=header.rlRowHeight; fontPoint>=1; fontPoint--){
		font.setPointSize(fontPoint);
		QFontMetrics tempFm(font);
		if(tempFm.height()<=header.rlRowHeight*3/4){
			break;
		}
	}

	painter.setFont(font);
	painter.drawText(image.rect(), Qt::AlignCenter, "Ruler");

	imageTo=image;

	return true;
}

bool BasicTracks::createBaseColorIndexImage(QImage& imageTo)
{
	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if(!RevisionDir.exists(RevisionsDirName)){
		return false;
	}
	if(!RevisionDir.cd(RevisionsDirName)){
		return false;
	}
	//species�̊m�F
	if(!RevisionDir.exists(CGIParam.species)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.species)){
		return false;
	}
	//revision�̊m�F
	if(!RevisionDir.exists(CGIParam.revision)){
		return false;
	}
	if(!RevisionDir.cd(CGIParam.revision)){
		return false;
	}
	//BinSeq�̊m�F
	QString binseqFileName(BinSeqFileTemp.arg(CGIParam.species).arg(CGIParam.revision));
	if(!RevisionDir.exists(binseqFileName)){
		return false;
	}
	BinSeq::FileReader reader;
	if(!reader.setFile(RevisionDir.filePath(binseqFileName))){
		return false;
	}
	quint64 targetSize;
	if(!reader.targetExists(CGIParam.target_name, targetSize)){
		return false;
	}
	if(CGIParam.start_from<1||CGIParam.start_from>targetSize){
		return false;
	}
	if(CGIParam.end_to<1||CGIParam.end_to>targetSize){
		return false;
	}	
	//config�擾
	header=reader.getTrackConfig();

	//�F�ύX�̗v��������Ή�����			
	if(CGIParam.color_for_a!=""){
		QByteArray colorArray=CGIParam.color_for_a.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForA.setNamedColor(colorString);
		}
        #else
		header.bgColorForA.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.color_for_c!=""){
		QByteArray colorArray=CGIParam.color_for_c.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForC.setNamedColor(colorString);
		}
        #else
		header.bgColorForC.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.color_for_g!=""){
		QByteArray colorArray=CGIParam.color_for_g.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForG.setNamedColor(colorString);
		}
        #else
		header.bgColorForG.setNamedColor(colorString);
        #endif
	}		
	if(CGIParam.color_for_t!=""){
		QByteArray colorArray=CGIParam.color_for_t.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForT.setNamedColor(colorString);
		}
        #else
		header.bgColorForT.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.color_for_n!=""){
		QByteArray colorArray=CGIParam.color_for_n.toLatin1();
		QString colorString=QUrl::fromPercentEncoding(colorArray);
		#if QT_VERSION >= 0x040700
		if(QColor::isValidColor(colorString)){
			header.bgColorForN.setNamedColor(colorString);
		}
        #else
		header.bgColorForN.setNamedColor(colorString);
        #endif
	}
	if(CGIParam.row_height>=20){
		header.bgRowHeight=CGIParam.row_height;
	}

	color_for_anti_a.setRgb(255-header.bgColorForA.red(), 255-header.bgColorForA.green(), 255-header.bgColorForA.blue());
	color_for_anti_c.setRgb(255-header.bgColorForC.red(), 255-header.bgColorForC.green(), 255-header.bgColorForC.blue());
	color_for_anti_g.setRgb(255-header.bgColorForG.red(), 255-header.bgColorForG.green(), 255-header.bgColorForG.blue());
	color_for_anti_t.setRgb(255-header.bgColorForT.red(), 255-header.bgColorForT.green(), 255-header.bgColorForT.blue());
	color_for_anti_n.setRgb(255-header.bgColorForN.red(), 255-header.bgColorForN.green(), 255-header.bgColorForN.blue());


	//�C���[�W�̗p��
	QImage image(IndexWidth, header.bgRowHeight, QImage::Format_RGB32);
	paintBackGround(Qt::white, &image);

	QFont font(QApplication::font());
	int fontPoint;

	for(fontPoint=header.bgRowHeight; fontPoint>=1; fontPoint--){
		font.setPointSize(fontPoint);
		QFontMetrics tempFm(font);
		if(tempFm.height()<=header.bgRowHeight*3/4){
			break;
		}
	}

	drawBaseChar(0, IndexWidth/4, 'A', 1, font, &image);
	drawBaseChar((IndexWidth*1)/4, IndexWidth/4, 'C', 1, font, &image);
	drawBaseChar((IndexWidth*2)/4, IndexWidth/4, 'G', 1, font, &image);
	drawBaseChar((IndexWidth*3)/4, IndexWidth/4, 'T', 1, font, &image);

	imageTo=image;

	return true;

}

void BasicTracks::
paintBackGround(	const QColor& color,
					QImage* image)
{
	QPainter painter(image);
	painter.setPen(Qt::NoPen);
	painter.setBrush(QBrush(color, Qt::SolidPattern));
	painter.drawRect(0, 0, image->width(), image->height());
}

void BasicTracks::
drawVarticalLine(	int h_pos,
					char base,
					int strand,
					QImage* image)
{
	QPainter painter(image);
	if(strand==1){
		switch(base){
			case 'A':
				painter.setPen(header.bgColorForA);
				break;
			case 'C':
				painter.setPen(header.bgColorForC);
				break;
			case 'G':
				painter.setPen(header.bgColorForG);
				break;
			case 'T':
				painter.setPen(header.bgColorForT);
				break;
			default:
				painter.setPen(header.bgColorForN);
				break;
		}
	}
	else if(strand==-1){
		switch(base){
			case 'A':
				painter.setPen(header.bgColorForT);
				break;
			case 'C':
				painter.setPen(header.bgColorForG);
				break;
			case 'G':
				painter.setPen(header.bgColorForC);
				break;
			case 'T':
				painter.setPen(header.bgColorForA);
				break;
			default:
				painter.setPen(header.bgColorForN);
				break;
		}
	}
	else{
		return;
	}
	painter.setBrush(Qt::NoBrush);
	painter.drawLine(h_pos, 0, h_pos, image->height()-1);
}

void BasicTracks::
drawBaseChar(	int h_start_pos,
				int h_width,
				char base,
				int strand,
				QFont font,
				QImage* image)
{

	QPainter painter(image);
	if(strand==1){
		switch(base){
			case 'A':
				painter.setPen(header.bgColorForA);
				painter.setBrush(header.bgColorForA);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_a);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, "A");
				break;
			case 'C':
				painter.setPen(header.bgColorForC);
				painter.setBrush(header.bgColorForC);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_c);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, "C");
				break;
			case 'G':
				painter.setPen(header.bgColorForG);
				painter.setBrush(header.bgColorForG);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_g);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, "G");
				break;
			case 'T':
				painter.setPen(header.bgColorForT);
				painter.setBrush(header.bgColorForT);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_t);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, "T");
				break;
			default:
				painter.setPen(header.bgColorForN);
				painter.setBrush(header.bgColorForN);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_n);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, QString(base));
				break;
		}
	}
	else if(strand==-1){
		switch(base){
			case 'A':
				painter.setPen(header.bgColorForT);
				painter.setBrush(header.bgColorForT);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_t);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, "T");
				break;
			case 'C':
				painter.setPen(header.bgColorForG);
				painter.setBrush(header.bgColorForG);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_g);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, "G");
				break;
			case 'G':
				painter.setPen(header.bgColorForC);
				painter.setBrush(header.bgColorForC);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_c);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, "C");
				break;
			case 'T':
				painter.setPen(header.bgColorForA);
				painter.setBrush(header.bgColorForA);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_a);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, "A");
				break;
			default:
				painter.setPen(header.bgColorForN);
				painter.setBrush(header.bgColorForN);
				painter.drawRect(h_start_pos, 0, h_width, image->height());
				painter.setBrush(Qt::NoBrush);
				painter.setPen(color_for_anti_n);
				painter.setFont(font);
				painter.drawText(h_start_pos, 0, h_width, image->height(), Qt::AlignCenter, QString(base));
				break;
		}
	}
	else{
		return;
	}

}

void BasicTracks::
drawGradLine(	const int& base_from,
				const int& base_to,
				const QColor& color,
				QImage* image)
{
	const qint64 minBpPos = base_from<base_to?base_from:base_to;
	const qint64 maxBpPos = base_from<base_to?base_to:base_from;
	const qint64 bpWidth = base_from<base_to?base_to-base_from+1:base_from-base_to+1;
	const qint64 imageWidth = image->width();
	const qint64 pixelPerGradMax = 150;
	const qint64 pixelPerGradMin = 50;

	//variables
	qint64 gradMinBpPos;
	qint64 gradMaxBpPos;
	qint64 bpPerGrad = 1;
	qint64 numOfGrad;
	qint64 pixelPerGrad;

	while(1){
		//
		gradMinBpPos
			= minBpPos + bpPerGrad - minBpPos%bpPerGrad;
		gradMaxBpPos
			= maxBpPos - maxBpPos%bpPerGrad;
		numOfGrad
			= (gradMaxBpPos-gradMinBpPos)/bpPerGrad+1;
		pixelPerGrad = imageWidth/numOfGrad;
		if( pixelPerGrad>=pixelPerGradMin && pixelPerGrad<=pixelPerGradMax){
			break;
		}
		bpPerGrad = bpPerGrad*2;
		
		gradMinBpPos
			= minBpPos + bpPerGrad - minBpPos%bpPerGrad;
		gradMaxBpPos
			= maxBpPos - maxBpPos%bpPerGrad;
		numOfGrad
			= (gradMaxBpPos-gradMinBpPos+1)/bpPerGrad+1;
		pixelPerGrad = imageWidth/numOfGrad;
		if( pixelPerGrad>=pixelPerGradMin && pixelPerGrad<=pixelPerGradMax){
			break;
		}
		bpPerGrad = (bpPerGrad*5)/2;

		gradMinBpPos
			= minBpPos + bpPerGrad - minBpPos%bpPerGrad;
		gradMaxBpPos
			= maxBpPos - maxBpPos%bpPerGrad;
		numOfGrad
			= (gradMaxBpPos-gradMinBpPos+1)/bpPerGrad+1;
		pixelPerGrad = imageWidth/numOfGrad;
		if( pixelPerGrad>=pixelPerGradMin && pixelPerGrad<=pixelPerGradMax){
			break;
		}
		bpPerGrad = bpPerGrad*2;
	}

	QPainter painter(image);
	painter.setPen(QPen(color, 1, Qt::DashLine));
	painter.setBrush(Qt::NoBrush);
	QFont font(QApplication::font());
	int fontPoint;

	for(fontPoint=header.ovRowHeight; fontPoint>=1; fontPoint--){
		font.setPointSize(fontPoint);
		QFontMetrics tempFm(font);
		if(tempFm.height()<=header.ovRowHeight*3/4){
			break;
		}
	}
	
	painter.setFont(font);
	QFontMetrics fm(font);

	qint64 gradBpPos;
	for(gradBpPos=gradMinBpPos; gradBpPos<=gradMaxBpPos; gradBpPos+=bpPerGrad){
		int hpos = (int)(((gradBpPos-minBpPos)*imageWidth)/bpWidth);
		QString displayString;
		if(bpPerGrad>Q_UINT64_C(1000000000)){
			if(bpPerGrad>=Q_UINT64_C(100000000000)){
				displayString = QString::number((qreal)(gradBpPos)/1000000000, 'f', 0);
			}
			else{
				displayString = QString::number((qreal)(gradBpPos)/1000000000, 'f', 1);
			}
			displayString.append("G");
		}
		else if(bpPerGrad>=1000000){
			if(bpPerGrad>=100000000){
				displayString = QString::number((qreal)(gradBpPos)/1000000, 'f', 0);
			}
			else{
				displayString = QString::number((qreal)(gradBpPos)/1000000, 'f', 1);
			}
			displayString.append("M");
		}
		else if(bpPerGrad>=1000){
			if(bpPerGrad>100000){
				displayString = QString::number((qreal)(gradBpPos)/1000, 'f', 0);
			}
			else{
				displayString = QString::number((qreal)(gradBpPos)/1000, 'f', 1);
			}
			displayString.append("K");
		}
		else{
			displayString = QString::number(gradBpPos);
		}

		//debug
		int with=fm.width(displayString);

		if(base_from<=base_to){
			painter.drawLine(hpos, 0, hpos, image->height()-1);
			painter.drawText(hpos+fm.averageCharWidth()/2, 0, hpos+fm.averageCharWidth()/2+fm.width(displayString), image->height(), Qt::AlignLeft|Qt::AlignVCenter, displayString);
		}
		else{
			painter.drawLine(imageWidth-hpos-1, 0, imageWidth-hpos-1, image->height()-1);
			painter.drawText(imageWidth-hpos-1, 0, hpos+fm.width(displayString), image->height(), Qt::AlignLeft|Qt::AlignVCenter, displayString);
		}
	}


}

void BasicTracks::
drawDisplayRegion(const int& base_from,
				  const int& base_to, 
				  const int& target_length,
				  const QColor& color, 
				  QImage* image)
{
	int minBpPos = base_from<base_to?base_from:base_to;
	int maxBpPos = base_from<base_to?base_to:base_from;
	int minPixelPos = (int)(((qint64)minBpPos*(qint64)image->width())/(qint64)target_length);
	int maxPixelPos = (int)(((qint64)maxBpPos*(qint64)image->width())/(qint64)target_length);

	QPainter painter(image);
	painter.setPen(Qt::NoPen);
	painter.setBrush(color);
	if(base_from<base_to){
		painter.drawRect(minPixelPos, 0, maxPixelPos-minPixelPos+1, image->height());
	}
	else{
		painter.drawRect(image->width()-maxPixelPos-1 , 0, maxPixelPos-minPixelPos+1, image->height());
	}
}


