#ifndef BINARY_SEQUENCE_H
#define BINARY_SEQUENCE_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>

using namespace std;

#include <QtCore>

#include "SeqInfo.h"
#include "DesktopTrackCommon.h"

namespace DesktopTrack{

	namespace BinSeq{

		struct Header{
			//magic
			qint32			magic;
			qint32			version;		//if version 2, size of int of "target" is 64
			//basic
			QString			species;
			QString			revision;
			//target info
			quint64			targetListOffset;		//
			quint32			targetListDataSize;
			quint32			targetListDataCount;
			//TrackConfig
			QColor			ovFgColor;
			QColor			ovBgColor;
			QColor			ovMarkColor;
			quint32			ovRowHeight;
			QColor			rlFgColor;
			QColor			rlBgColor;
			quint32			rlRowHeight;
			QColor			bgColorForA;
			QColor			bgColorForC;
			QColor			bgColorForG;
			QColor			bgColorForT;
			QColor			bgColorForN;
			quint32			bgRowHeight;

			Header(void);
			Header(const Header& original);

			Header& operator=(const Header& original);

			void putSerialized(QDataStream& out);
			void getSerialized(QDataStream& in);
		};

		struct Target{
			static qint32 version;		//default 1, versions are 1 or 2
										// if 1, targetOffset and targetLength are 32 byte
										// if 2, targetOffset and targetLength are 64 byte
			QString		targetName;
			quint64		targetOffset;
			quint64		targetLength;

			Target(void);
			Target(const QString& target_name, const quint64& target_length);
			Target(const Target& original);
			Target& operator=(const Target& original);
			void putSerialized(QDataStream& out);
			void getSerialized(QDataStream& in);
			bool operator<(const Target& with);

			static void setVersion(const qint32 version);
		};

		struct TargetLess{
			TargetLess(void);
			bool operator()(const Target& a, const Target& b);
		};

		struct TargetShort{
			TargetShort(void);
			bool operator()(const Target& a, const Target& b);
		};

		struct TargetLarge{
			TargetLarge(void);
			bool operator()(const Target& a, const Target& b);
		};

		class FileCreator:public QThread{
		public:
			enum Process{processing, stopped, failed, finished};

		private:

			Header				header;
			QString				pathToBinSeq;
			SeqInfoList			seqInfoList;

			//-----thread�ԒʐM�p�ϐ���������-----
			QMutex	mutex;
			bool	promoteProcess;
			Process processStatus;
			quint64	processedData;
			quint64	totalData;
			//-----thread�ԒʐM�p�ϐ������܂�-----

			//Thread Safe
			void setProcessStatus(	const Process& process_status,
									const quint64& prosessed_data,
									const quint64& total_data);
			//Thread Safe
			bool getOrder(void);

			void run(void);

		public:
			FileCreator(QObject* parent=0);
			void initialize(const QString& path_to_binaryseq_file,
							const Header& header,
							const SeqInfoList& seq_info_list);
			//Thread Safe
			void setOrder(bool proceed);
			//Thread Safe
			void getProcessStatus(	Process& process_status,
									quint64& prosessed_data,
									quint64& total_data);

		};

		struct FileReader: public QObject{
            Q_OBJECT
		public:
			enum ProcessMode{single, batch};
		private:
			Header								header;
			QList<Target>						targetList;
			QList<QByteArray>					targetSeqList;
			QFile								file;
			//char*								fileData;
			ProcessMode							mode;
		public:
			FileReader(QObject* parent=0);
			~FileReader();	
			bool setFile(const QString& pathToBinarySeqFile, ProcessMode mode=single);
			bool releaseFile(void);
			
			const Header&			getTrackConfig(void) const;
			const QList<Target>&	getTargetList(void) const;

			bool targetExists(const QString& targetName, quint64& sizeTo);
			bool getSeq(const QString& targetName, QByteArray& to);
			bool getSeq(const QString& targetName,
						const quint64& start,
						const quint64& end,
						QByteArray& to);
			bool updateConfig(const Header& new_conf);

		};

	};

};

#endif
