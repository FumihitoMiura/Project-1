#include <QtCore>
#include <QtGui>

#include <cstdlib>

#include "BasicTracksCGIParam.h"
#include "BasicTracks.h"

int main(int argc, char* argv[])
{
	QApplication app(argc, argv, false);
	QDir appDir(app.applicationDirPath());
	int font_id=QFontDatabase::addApplicationFont(":/font/ArenaCondensed.ttf");
	QStringList fontFamilies=QFontDatabase::applicationFontFamilies(font_id);
	QFontDatabase fontDatabase;
	QApplication::setFont(fontDatabase.font(fontFamilies[0], "normal", 12));
	
	DesktopTrack::BasicTracks basicTracks;
	basicTracks.printTrackLayer();
}


