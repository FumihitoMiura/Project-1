#ifndef CGI_PARAM_H
#define CGI_PARAM_H

#include <QtCore>
#include <QtGui>
#include <cstdlib>


namespace DesktopTrack{

	struct BasicTracksCGIParam{
		bool				is_cgi;
		//basic
		QString				track_layer;	//image, index_image, operation, index_operation, query
		QString				track_name;		//overview ruler basecolor
		QString				species;		//
		QString				revision;
		QString				target_name;
		quint32				start_from;
		quint32				end_to;
		quint32				pixel_width;

		//config
		QString				foreground_color;
		QString				background_color;
		QString				dispregion_color;
		quint32				row_height;
		QString				color_for_a;
		QString				color_for_c;
		QString				color_for_g;
		QString				color_for_t;
		QString				color_for_n;

		QList<QPair<QString, QString> > anotherParam;

		QString				address;

		//methods
		BasicTracksCGIParam(void);

	};

};

#endif

