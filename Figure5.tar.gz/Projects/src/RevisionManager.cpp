#include "RevisionManager.h"

using namespace DesktopTrack;



//20090318�m�F�ς�
RevisionManager::RevisionManager(QWidget* parent)
:FileDialog(this), FileListModel(this), fastaFileAnalyzer(this), 
timer(this), pdialog(this), seqInfoListTableModel(this), QDialog(parent)
{
	/*---------------------------------------------------
	      �f�B���N�g���\���̏�����
	---------------------------------------------------*/
	//Revisions�f�B���N�g���̑��݊m�F
	//�f�B���N�g��������species-revision�̃c���[�\����L��
	//revision�̏����i�[���邻�̃��[�g���m�F
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.exists(RevisionsDirName)){
		if(!revision_dir.mkdir(RevisionsDirName)){
			QApplication::exit();
		}
	}
	else{
		QFileInfo fi(revision_dir.filePath(RevisionsDirName));
		if(!fi.isDir()){
			QApplication::exit();
		}
	}
	if(!revision_dir.cd(RevisionsDirName)){
		QApplication::exit();
	}

	/*---------------------------------------------------
	      GUI�֘A�̏�����
	---------------------------------------------------*/
	setupUi(this);

	//���͐���
	SpeciesLineEdit->setValidator(new QRegExpValidator(InputValidator, this));
	RevisionLineEdit->setValidator(new QRegExpValidator(InputValidator, this));

	//SIGNAL->SLOT
	connect(SpeciesComboBox, SIGNAL(currentIndexChanged(int)),
			this, SLOT(onSelectSpeciesComboBox(int)));
	connect(SpeciesLineEdit, SIGNAL(textEdited(const QString&)),
			this, SLOT(onEditSpeciesLineEdit(const QString&)));
	connect(createSpeciesPushButton, SIGNAL(pressed()),
			this, SLOT(onClickCreateSpeciesPushButton()));
	connect(RevisionComboBox, SIGNAL(currentIndexChanged(int)),
			this, SLOT(onSelectRevisionComboBox(int)));
	connect(RevisionLineEdit, SIGNAL(textEdited(const QString&)),
			this, SLOT(onEditRevisionLineEdit(const QString&)));
	connect(selectFilePushButton, SIGNAL(pressed()),
			this, SLOT(onClickFileSelectPushButton()));
	
	//�t�@�C���_�C�A���O�̏����ݒ�
	FileDialog.setAcceptMode(QFileDialog::AcceptOpen);
	FileDialog.setFileMode(QFileDialog::ExistingFiles);
	FileDialog.setDirectory(QCoreApplication::applicationDirPath());
	FileDialog.setViewMode(QFileDialog::Detail);
	FileDialog.setModal(true);
	FileDialog.setLabelText(QFileDialog::LookIn, tr("Select FASTA or GFF formatted files."));
	QStringList filters;
	filters	<< "FASTA files (*.fasta *.fsa *.fa)"
			<< "GFF files (*.gff *.gtf)";
	FileDialog.setNameFilters(filters);
	connect(&FileDialog, SIGNAL(filesSelected(const QStringList&)),
			this, SLOT(onFilesSelected(const QStringList&)));
	fileListView->setModel(&FileListModel);
	connect(removeFilePushButton, SIGNAL(pressed()),
			this, SLOT(onClickRemoveFilePushButton()));
	connect(startAnalysisPushButton, SIGNAL(pressed()),
			this, SLOT(onClickStartAnalysisPushButton()));

	connect(createRevisionPushButton, SIGNAL(pressed()),
			this, SLOT(onPushCreateRevisionButton()));

	seqInfoListTableView->setModel(&seqInfoListTableModel);


	//�^�C�}�[�̏����ݒ�
	timer.setSingleShot(false);
	timer.setInterval(500);
	
	//progress dialog
	pdialog.setWindowModality(Qt::WindowModal);
	pdialog.cancel();

	//SpeciesComboBox/SpeciesLineEdit�̏�����
	QStringList list;
	getSpecies(list);
	for(int i=0; i<list.size(); i++){
		SpeciesComboBox->addItem(list[i]);
	}
	SpeciesComboBox->addItem("Create New Species");

}

//20090318�m�F�ς�
void RevisionManager::onSelectSpeciesComboBox(int index)
{
	if(SpeciesComboBox->itemText(index)=="Create New Species"){
		//Species�֘A
		removeSpeciesPushButton->setEnabled(false);
		SpeciesLineEdit->setEnabled(true);
		createSpeciesPushButton->setEnabled(false);
		onEditSpeciesLineEdit(SpeciesLineEdit->text());
		//Revision�֘A
		RevisionComboBox->clear();
		RevisionComboBox->setEnabled(false);
		removeRevisionPushButton->setEnabled(false);
		RevisionLineEdit->setText("");
		RevisionLineEdit->setEnabled(false);
		createRevisionPushButton->setEnabled(false);
		//source file table�̏�����
		FileList.clear();
		FileListModel.setStringList(FileList);
		fileListView->setEnabled(false);
		//sequence list�̏������ƕs����
		SeqInfoList seqInfoList;
		seqInfoListTableModel.setSeqInfoList(seqInfoList);
		seqInfoListTableModel.setEditable(true);
		seqInfoListTableView->resizeColumnsToContents();
		seqInfoListTableView->setEnabled(false);
		renameSequenceGroupBox->setEnabled(false);
	}
	else{
		//Species�֘A
		removeSpeciesPushButton->setEnabled(true);
		SpeciesLineEdit->setEnabled(false);
		SpeciesLineEdit->setEnabled(false);
		createSpeciesPushButton->setEnabled(false);
		//Revision�֘A
		QStringList list;
		getRevision(SpeciesComboBox->itemText(index), list);
		RevisionComboBox->clear();
		RevisionComboBox->setEnabled(true);
		for(int i=0; i<list.size(); i++){
			RevisionComboBox->addItem(list[i]);
		}
		RevisionComboBox->addItem("Create New Revision");
		
	}
}

//20090318�m�F�ς�
void RevisionManager::onEditSpeciesLineEdit(const QString& text)
{
	if(text.size()==0){
		createSpeciesPushButton->setEnabled(false);
		messageLabel->setText(tr("Please input new species name."));
	}
	else if(speciesExists(text)){
		createSpeciesPushButton->setEnabled(false);
		messageLabel->setText(tr("The species name already registered."));
	}
	else{
		createSpeciesPushButton->setEnabled(true);
		messageLabel->setText(tr("If ready, push create button."));
	}
}

//20090318�C���ς�
void RevisionManager::onClickCreateSpeciesPushButton(void)
{
	//�{�^����s������
	createSpeciesPushButton->setEnabled(false);
	QString species = SpeciesLineEdit->text();
	SpeciesLineEdit->setText("");
	//Revision�f�B���N�g�����`�F�b�N���A�Ȃ������ɑ��݂��Ă����牽�����Ȃ�
	if(speciesExists(species)){
		messageLabel->setText(tr("The species name already registered."));
		return;
	}
	if(!putSpecies(species)){
		messageLabel->setText(tr("Failed to register species."));
		return;		
	}
	//�R���{�{�b�N�X�ɓo�^
	int i;
	for(i=0; i<SpeciesComboBox->count()-1; i++){
		if(species<SpeciesComboBox->itemText(i)){
			SpeciesComboBox->insertItem(i, species);
			SpeciesComboBox->setCurrentIndex(i);
			return;
		}
	}
	SpeciesComboBox->insertItem(i, species);
	SpeciesComboBox->setCurrentIndex(i);
}

//20090318�m�F�ς�
void RevisionManager::onSelectRevisionComboBox(int index)
{
	if(RevisionComboBox->itemText(index)=="Create New Revision"){
		removeRevisionPushButton->setEnabled(false);
		RevisionLineEdit->setEnabled(true);
		RevisionLineEdit->setText("");
		createRevisionPushButton->setEnabled(false);
		onEditRevisionLineEdit(RevisionLineEdit->text());
		//
		selectFilePushButton->setEnabled(true);
		removeFilePushButton->setEnabled(false);
		startAnalysisPushButton->setEnabled(false);
		//source file table�̏�����
		FileList.clear();
		FileListModel.setStringList(FileList);
		fileListView->setEnabled(false);
		//sequence list�̏������ƕs����
		SeqInfoList seqInfoList;
		seqInfoListTableModel.setSeqInfoList(seqInfoList);
		seqInfoListTableModel.setEditable(true);
		seqInfoListTableView->resizeColumnsToContents();
		seqInfoListTableView->setEnabled(false);
		renameSequenceGroupBox->setEnabled(false);
		connect(	fileListView->selectionModel(), 
					SIGNAL(currentRowChanged(const QModelIndex&, const QModelIndex&)),
					this, 
					SLOT(onChangeFileListSelect(const QModelIndex&, const QModelIndex&)));
	}
	else{
		//����̃��r�W�������w�肳�ꂽ���́A�����s�������ď���\������
		removeRevisionPushButton->setEnabled(true);
		RevisionLineEdit->setEnabled(false);
		RevisionLineEdit->setText("");
		createRevisionPushButton->setEnabled(false);
		selectFilePushButton->setEnabled(false);
		removeFilePushButton->setEnabled(false);
		startAnalysisPushButton->setEnabled(false);
		renameSequenceGroupBox->setEnabled(false);
		QString species = SpeciesComboBox->itemText(SpeciesComboBox->currentIndex());
		QString revision = RevisionComboBox->itemText(index);
		//file list view
		FileList.clear();
		FileListModel.setStringList(FileList);
		fileListView->setEnabled(true);
		disconnect(fileListView->selectionModel(), 0, 0, 0);
		renameSequenceGroupBox->setEnabled(false);
		//sequence list
		SeqInfoList seqInfoList;
		getSeqInfoList(species, revision, seqInfoList);
		seqInfoListTableModel.setSeqInfoList(seqInfoList);
		seqInfoListTableModel.setEditable(false);
		seqInfoListTableView->resizeColumnsToContents();
		seqInfoListTableView->setEnabled(true);
	}
}

//20090318�m�F�ς�
void RevisionManager::onClickFileSelectPushButton(void)
{
	FileDialog.show();
}

//20090318�m�F�ς�
void RevisionManager::onFilesSelected(const QStringList& files)
{
	for(int i=0; i<files.size(); i++){
		if(!FileList.contains(files[i])){
			FileList.append(files[i]);
		}
	}
	FileList.sort();
	FileListModel.setStringList(FileList);
	if(FileList.size()>0){
		startAnalysisPushButton->setEnabled(true);
		fileListView->setEnabled(true);
	}
	removeFilePushButton->setEnabled(false);
}

//20090318�m�F�ς�
void RevisionManager::
onChangeFileListSelect(const QModelIndex& current, const QModelIndex& /*previous*/)
{
	if(!current.isValid()){
		removeFilePushButton->setEnabled(false);
		return;
	}
	QString selectedPath = current.data().toString();
	if(FileList.contains(selectedPath)){
		removeFilePushButton->setEnabled(true);
	}
	else{
		removeFilePushButton->setEnabled(false);
	}
}

//20090318�m�F�ς�
void RevisionManager::
onClickRemoveFilePushButton(void)
{
	removeFilePushButton->setEnabled(false);
	QModelIndex currentSelection = fileListView->selectionModel()->currentIndex();
	if(!currentSelection.isValid()){
		return;
	}
	QString selectedPath = currentSelection.data().toString();
	if(FileList.contains(selectedPath)){
		FileList.removeAt(FileList.indexOf(selectedPath));
		FileListModel.setStringList(FileList);
		if(FileList.size()>0){
			startAnalysisPushButton->setEnabled(true);
		}
		else{
			startAnalysisPushButton->setEnabled(false);
		}
		SeqInfoList seqInfoList;
		seqInfoListTableModel.setSeqInfoList(seqInfoList);
		return;
	}
}

//20090318�m�F�ς�
void RevisionManager::
onClickStartAnalysisPushButton(void)
{
	fastaFileAnalyzer.setFilePath(FileList);
	fastaFileAnalyzer.setOrder(true);
	selectFilePushButton->setEnabled(false);
	removeFilePushButton->setEnabled(false);
	startAnalysisPushButton->setEnabled(false);

	//�^�C�}�[��FastaFile��͗p�̃X���b�g���Ȃ�
	connect(&timer, SIGNAL(timeout()),
		this, SLOT(onTimeOutFastaFileAnalysis()));
	//�_�C�A���O���Ȃ�
	pdialog.setLabelText(tr("Analyzing FASTA file(s) ..."));
	connect(&pdialog, SIGNAL(canceled()), 
		this, SLOT(onCancelFileAnalysis()));

	fastaFileAnalyzer.start();
	timer.start();
	pdialog.exec();
	
}

//20090318�m�F�ς�
void RevisionManager::
onTimeOutFastaFileAnalysis(void)
{
	FastaFileAnalyzer::Process	process_status;
	quint64	prosessed_data;
	quint64	total_data;
	fastaFileAnalyzer.getProcessStatus(process_status, prosessed_data, total_data);
	int progress;
	if(total_data!=0){
		progress = (int)((100*prosessed_data)/total_data);
	}
	else{
		progress = 0;
	}
	switch(process_status){

		case FastaFileAnalyzer::underway:

			pdialog.setValue(progress);
			break;

		case FastaFileAnalyzer::stopped:

			//�������~
			timer.stop();
			disconnect(&timer, SIGNAL(timeout()),
				this, SLOT(onTimeOutFastaFileAnalysis()));
			disconnect(&pdialog, SIGNAL(canceled()),
				this, SLOT(onCancelFileAnalysis()));
			selectFilePushButton->setEnabled(true);
			startAnalysisPushButton->setEnabled(true);
			pdialog.cancel();
			break;

		case FastaFileAnalyzer::failed:

			//�������~
			timer.stop();
			disconnect(&timer, SIGNAL(timeout()),
				this, SLOT(onTimeOutFastaFileAnalysis()));
			disconnect(&pdialog, SIGNAL(canceled()),
				this, SLOT(onCancelFileAnalysis()));
			selectFilePushButton->setEnabled(true);
			startAnalysisPushButton->setEnabled(true);
			pdialog.cancel();
			//���b�Z�[�W
			QMessageBox::warning(this, "Warning", "Failed to analyze FASTA file(s)");

			break;

		case FastaFileAnalyzer::finished:

			//�������~
			timer.stop();
			disconnect(&timer, SIGNAL(timeout()),
				this, SLOT(onTimeOutFastaFileAnalysis()));
			disconnect(&pdialog, SIGNAL(canceled()),
				this, SLOT(onCancelFileAnalysis()));
			pdialog.setValue(100);
			pdialog.cancel();

			//�e�[�u���X�V
			SeqInfoList seqInfoList = fastaFileAnalyzer.getSeqInfo();
			selectFilePushButton->setEnabled(true);
			removeFilePushButton->setEnabled(true);
			seqInfoListTableModel.setSeqInfoList(seqInfoList);
			seqInfoListTableView->resizeColumnsToContents();
			seqInfoListTableView->setEnabled(true);
			renameSequenceGroupBox->setEnabled(true);
			onEditRevisionLineEdit(RevisionLineEdit->text());

			//���r�W�����o�^�{�^��������
			//createRevisionPushButton->setEnabled(true);

			break;

	}
}

void RevisionManager::onCancelFileAnalysis(void)
{
	fastaFileAnalyzer.setOrder(false);
	disconnect(&pdialog, SIGNAL(canceled()),
		this, SLOT(onClickCancelFileAnalysisPushButton()));
}

//20090318�m�F�ς�
void RevisionManager::onEditRevisionLineEdit(const QString& text)
{
	QString species = SpeciesComboBox->itemText(SpeciesComboBox->currentIndex());
	if(text.size()==0){
		createRevisionPushButton->setEnabled(false);
		messageLabel->setText(tr("Please input new revision name."));
	}
	else if(revisionExists(species, text)){
		createRevisionPushButton->setEnabled(false);
		messageLabel->setText(tr("The revision name already registered."));
	}
	else if(seqInfoListTableModel.getSeqInfoList().size()>0){
		createRevisionPushButton->setEnabled(true);
		messageLabel->setText(tr("If ready, push create button."));
	}
}

//20090317�C���ς�
bool RevisionManager::getSpecies(QStringList& speciesTo)
{
	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.cd(RevisionsDirName)){
		return false;
	}
	//�����̑S�Ă�Species���擾
	speciesTo=revision_dir.entryList(QDir::AllDirs|QDir::NoDotAndDotDot, QDir::Name);
	if(speciesTo.size()>0){
		return true;
	}
	else{
		return false;
	}
}

//20090317�C���ς�
bool RevisionManager::speciesExists(const QString& species)
{
	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.cd(RevisionsDirName)){
		return false;
	}
	QStringList speciesList=revision_dir.entryList(QDir::AllDirs|QDir::NoDotAndDotDot, QDir::Name);
	if(speciesList.contains(species, Qt::CaseSensitive)){
		return true;
	}
	else{
		return false;
	}
}

//20090318�C���ς�
bool RevisionManager::
putSpecies(	const QString& species)
{
	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.cd(RevisionsDirName)){
		return false;
	}
	//species�����ɑ��݂���Ȃ甲����
	if(revision_dir.exists(species)){
		return false;
	}
	//species���̃f�B���N�g�������Ȃ���Δ�����
	else if(!revision_dir.mkdir(species)){
		return false;
	}
	return true;
}

//20090317�C���ς�
bool RevisionManager::
getRevision(const QString& species,
			QStringList& revisionsTo)
{
	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.cd(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(species)){
		return false;
	}	
	revisionsTo=revision_dir.entryList(QDir::AllDirs|QDir::NoDotAndDotDot, QDir::Name);
	if(revisionsTo.size()>0){
		return true;
	}
	else{
		return false;
	}
}

//20090317�C���ς�
bool RevisionManager::
revisionExists(	const QString& species,
				const QString& revision)
{
	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.exists(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(species)){
		return false;
	}	
	QStringList revisionsList=revision_dir.entryList(QDir::AllDirs|QDir::NoDotAndDotDot, QDir::Name);
	if(revisionsList.contains(revision, Qt::CaseSensitive)){
		return true;
	}
	else{
		return false;
	}
}

//20090327�ǉ�
bool RevisionManager::
getRivisionDir(	const QString& species,
				const QString& revision,
				QString& revisionDirTo)
{
	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.exists(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(species)){
		return false;
	}	
	if(!revision_dir.cd(revision)){
		return false;
	}
	revisionDirTo=revision_dir.absolutePath();
	return true;
}

//20090317�C���ς�
bool RevisionManager::
getTarget(	const QString& species, 
			const QString& revision, 
			QList<QPair<QString, quint32> >& queryListTo)
{
	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.exists(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(species)){
		return false;
	}	
	if(!revision_dir.cd(revision)){
		return false;
	}
	QStringList fileList=revision_dir.entryList(QDir::Files, QDir::Name);
	if(!fileList.contains(RevisionFileName, Qt::CaseSensitive)){
		return false;
	}
	
	QFile revisionInfoXmlFile(revision_dir.filePath(RevisionFileName));
	if(!revisionInfoXmlFile.open(QIODevice::ReadOnly)){
		return false;
	}
	QDomDocument domDoc(RevisionTag);
	if(!domDoc.setContent(&revisionInfoXmlFile)){
		revisionInfoXmlFile.close();
		return false;
	}
	revisionInfoXmlFile.close();

	QDomElement docElem = domDoc.documentElement();

	//species�̊m�F
	QDomNodeList nodeList=docElem.elementsByTagName(SpeciesTag);
	if(nodeList.size()!=1){
		return false;
	}
	if(!nodeList.item(0).isElement()){
		return false;
	}
	else if(nodeList.item(0).toElement().attributeNode(NameAttr).value()!=species){
		return false;
	}
	//revision�̊m�F
	nodeList=docElem.elementsByTagName(RevisionTag);
	if(nodeList.size()!=1){
		return false;
	}
	if(!nodeList.item(0).isElement()){
		return false;
	}
	else if(nodeList.item(0).toElement().attributeNode(NameAttr).value()!=revision){
		return false;
	}
	//target���̎擾
	queryListTo.clear();
	nodeList=docElem.elementsByTagName(TargetTag);
	for(int i=0; i<nodeList.size(); i++){

		if(!nodeList.item(i).isElement()){
			continue;
		}
		QString name=nodeList.item(i).toElement().attributeNode(NameAttr).value();
		quint32 value=nodeList.item(i).toElement().attributeNode(LengthAttr).value().toUInt();
		queryListTo.push_back(qMakePair(name, value));
	}
	return true;

}

//20090317�C���ς�
bool RevisionManager::
getSeqInfoList(	const QString& species,
				const QString& revision,
				SeqInfoList& seqInfoListTo)
{
	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.exists(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(species)){
		return false;
	}	
	if(!revision_dir.cd(revision)){
		return false;
	}
	QStringList fileList=revision_dir.entryList(QDir::Files, QDir::Name);
	if(!fileList.contains(RevisionFileName, Qt::CaseSensitive)){
		return false;
	}
	
	QFile revisionInfoXmlFile(revision_dir.filePath(RevisionFileName));
	if(!revisionInfoXmlFile.open(QIODevice::ReadOnly)){
		return false;
	}
	QDomDocument domDoc(RevisionTag);
	if(!domDoc.setContent(&revisionInfoXmlFile)){
		revisionInfoXmlFile.close();
		return false;
	}
	revisionInfoXmlFile.close();

	QDomElement docElem = domDoc.documentElement();

	//species�̊m�F
	QDomNodeList nodeList=docElem.elementsByTagName(SpeciesTag);
	if(nodeList.size()!=1){
		return false;
	}
	if(!nodeList.item(0).isElement()){
		return false;
	}
	else if(nodeList.item(0).toElement().attributeNode(NameAttr).value()!=species){
		return false;
	}
	//revision�̊m�F
	nodeList=docElem.elementsByTagName(RevisionTag);
	if(nodeList.size()!=1){
		return false;
	}
	if(!nodeList.item(0).isElement()){
		return false;
	}
	else if(nodeList.item(0).toElement().attributeNode(NameAttr).value()!=revision){
		return false;
	}

	//target���̎擾
	seqInfoListTo.clear();
	nodeList=docElem.elementsByTagName(TargetTag);
	for(int i=0; i<nodeList.size(); i++){
		if(!nodeList.item(i).isElement()){
			continue;
		}
		QDomElement element=nodeList.item(i).toElement();
		SeqInfo info;
		info.seqId=element.attributeNode(NameAttr).value();
		info.renameTo=element.attributeNode(AliasAttr).value();
		info.descriptions=element.attributeNode(DescAttr).value();
		info.seqLength=element.attributeNode(LengthAttr).value().toLongLong();
		info.seqFilePath=revision_dir.filePath(element.attributeNode(PathAttr).value());
		info.fileOffset=element.attributeNode(OffsetAttr).value().toLongLong();
		seqInfoListTo.append(info);
	}
	return true;
}

//20090317�C���ς�
//FastaFile�̃p�X��Ԃ�
bool RevisionManager::
getFastaPath(	const QString& species, 
				const QString& revision, 
				QString& fastaPathTo)
{
	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.exists(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(RevisionsDirName)){
		return false;
	}
	if(!revision_dir.cd(species)){
		return false;
	}	
	if(!revision_dir.cd(revision)){
		return false;
	}
	QStringList fileList=revision_dir.entryList(QDir::Files, QDir::Name);
	if(!fileList.contains(RevisionFileName, Qt::CaseSensitive)){
		return false;
	}
	
	QFile revisionInfoXmlFile(revision_dir.filePath(RevisionFileName));
	if(!revisionInfoXmlFile.open(QIODevice::ReadOnly)){
		return false;
	}
	QDomDocument domDoc(RevisionTag);
	if(!domDoc.setContent(&revisionInfoXmlFile)){
		revisionInfoXmlFile.close();
		return false;
	}
	revisionInfoXmlFile.close();

	QDomElement docElem = domDoc.documentElement();

	//species�̊m�F
	QDomNodeList nodeList=docElem.elementsByTagName(SpeciesTag);
	if(nodeList.size()!=1){
		return false;
	}
	if(!nodeList.item(0).isElement()){
		return false;
	}
	else if(nodeList.item(0).toElement().attributeNode(NameAttr).value()!=species){
		return false;
	}
	//revision�̊m�F
	nodeList=docElem.elementsByTagName(RevisionTag);
	if(nodeList.size()!=1){
		return false;
	}
	if(!nodeList.item(0).isElement()){
		return false;
	}
	else if(nodeList.item(0).toElement().attributeNode(NameAttr).value()!=revision){
		return false;
	}

	//fastafile��path���擾
	nodeList=docElem.elementsByTagName(FastaFileTag);
	if(nodeList.size()!=1){
		return false;
	}
	if(!nodeList.item(0).isElement()){
		return false;
	}
	QString file_name=nodeList.item(0).toElement().attributeNode(PathAttr).value();
	fastaPathTo=revision_dir.filePath(file_name);
	return true;
}

void RevisionManager::onPushCreateRevisionButton(void)
{
	//�{�^����2�x�����X�g�b�v
	createRevisionPushButton->setEnabled(false);

	SeqInfoList seqInfoList = seqInfoListTableModel.getSeqInfoList();
	QString species = SpeciesComboBox->itemText(SpeciesComboBox->currentIndex());
	QString revision = RevisionLineEdit->text();

	//RevisionDir�Ɉړ�
	QDir revision_dir(QApplication::applicationDirPath());
	if(!revision_dir.exists(RevisionsDirName)){
		QMessageBox::warning(this, "Warning", QString("Cannot find %1 directory").arg(RevisionsDirName));
		return;
	}
	if(!revision_dir.cd(RevisionsDirName)){
		QMessageBox::warning(this, "Warning", QString("Cannot open %1 directory").arg(RevisionsDirName));
		return;
	}
	if(!revision_dir.cd(species)){
		QMessageBox::warning(this, "Warning", QString("Cannot open %1 directory").arg(species));
		return;
	}
	//revision�̃f�B���N�g�����쐬
	if(!revision_dir.mkdir(revision)){
		QMessageBox::warning(this, "Warning", QString("Cannot create %1 directory").arg(revision));
		return;
	}
	//revision�̃f�B���N�g���Ɉړ�
	if(!revision_dir.cd(revision)){
		QMessageBox::warning(this, "Warning", QString("Cannot open %1 directory").arg(revision));
		return;
	}

	//XML�h�L�������g��p��
	doc.clear();
	//QDomDocument doc(RevisionFileRootTag);
	QDomElement root=doc.createElement(RevisionFileRootTag);
	doc.appendChild(root);

	//species�̓o�^
	QDomElement speciesElem=doc.createElement(SpeciesTag);
	speciesElem.setAttribute(NameAttr, species);
	root.appendChild(speciesElem);

	//revision�̓o�^
	QDomElement revisionElem=doc.createElement(RevisionTag);
	revisionElem.setAttribute(NameAttr, revision);
	root.appendChild(revisionElem);

	//source file���i�[����f�B���N�g�����쐬
	QDir sourceDir(revision_dir);
	if(!sourceDir.mkdir(RevisionSourceDirName)){
		QMessageBox::warning(this, "Warning", QString("Cannot create source file directory"));
		return;
	}
	else if(!sourceDir.cd(RevisionSourceDirName)){
		QMessageBox::warning(this, "Warning", QString("Cannot open source file directory"));
		return;		
	}

	//source file���i�[����f�B���N�g����o�^
	QDomElement sourceElem=doc.createElement(SourceDirTag);
	sourceElem.setAttribute(PathAttr, RevisionSourceDirName);
	root.appendChild(sourceElem);

	//�I���W�i���t�@�C���̃R�s�[����J�n
	QDir revisionSourceDir(revision_dir);
	QStringList origFiles;
	QStringList destFiles;
	int i;
	for(i=0; i<FileList.size(); i++){
		QFileInfo info(FileList[i]);
		QString destFileName=sourceDir.filePath(info.fileName());
		origFiles.push_back(FileList[i]);
		destFiles.push_back(destFileName);
		FileList[i]=revision_dir.relativeFilePath(destFileName);
	}
    if(!fileCopy.setFiles(origFiles, destFiles)){
		QMessageBox::warning(this, "Warning", QString("Cannot store the original file(s)"));
        return;
    }
	fileCopy.setOrder(true);

	//�_�C�A���O�̏���
	pdialog.setValue(0);
	pdialog.setLabelText(tr("Copying original fles to revision directory ..."));
	connect(&pdialog, SIGNAL(canceled()),
		this, SLOT(onCancelFileCopy()));

    //�^�C�}�[�̏���
    timer.disconnect();
    connect(&timer, SIGNAL(timeout()),
            this, SLOT(onTimeOutFileCopy()));

	//�R�s�[�J�n
    timer.start();
    fileCopy.start();
	pdialog.exec();

}


void RevisionManager::onTimeOutFileCopy(void)
{
    FileCopy::Process	process_status;
    quint64	prosessed_data;
    quint64	total_data;
    fileCopy.getProcessStatus(process_status, prosessed_data, total_data);
    int progress;
    if(total_data!=0){
        progress = (int)((100*prosessed_data)/total_data);
    }
    else{
        progress = 0;
    }
    switch(process_status){

        case FileCopy::processing:

			pdialog.setValue(progress);
            break;

        case FileCopy::stopped:

			//�������~
			timer.stop();
			disconnect(&timer, SIGNAL(timeout()),
				this, SLOT(onTimeOutFileCopy()));
			disconnect(&pdialog, SIGNAL(canceled()),
				this, SLOT(onCancelFileCopy()));
			pdialog.cancel();
			break;

        case FileCopy::finished:

			//�܂��͏������~
            timer.stop();
			disconnect(&timer, SIGNAL(timeout()),
				this, SLOT(onTimeOutFileCopy()));
			disconnect(&pdialog, SIGNAL(canceled()),
				this, SLOT(onCancelFileCopy()));
			pdialog.setValue(100);
			pdialog.cancel();

            //�ēx�����擾
            SeqInfoList seqInfoList = seqInfoListTableModel.getSeqInfoList();
            QString species = SpeciesComboBox->itemText(SpeciesComboBox->currentIndex());
            QString revision = RevisionLineEdit->text();
            //RevisionDir�Ɉړ�
            QDir revision_dir(QApplication::applicationDirPath());
            if(!revision_dir.exists(RevisionsDirName)){
                return;
            }
            if(!revision_dir.cd(RevisionsDirName)){
                return;
            }
            if(!revision_dir.exists(species)){
                return;
            }
            if(!revision_dir.cd(species)){
                return;
            }
            //revision�̃f�B���N�g���Ɉړ�
            if(!revision_dir.exists(revision)){
                return;
            }
            if(!revision_dir.cd(revision)){
                return;
            }
			//source file���i�[����f�B���N�g�����쐬
			QDir sourceDir(revision_dir);
			if(!sourceDir.cd(RevisionSourceDirName)){
				return;		
			}
			//targets�̓o�^
			QDomElement root=doc.documentElement();
			QDomElement targetsElem=doc.createElement(TargetsTag);
			targetsElem.setAttribute(NumOfTargetsAttr, seqInfoList.size());
			root.appendChild(targetsElem);
			//���ꂼ��̃^�[�Q�b�g����XML�ɓo�^
			//�R�s�[���filepath
			for(int i=0; i<seqInfoList.size(); i++){
				QDomElement targetElem=doc.createElement(TargetTag);
				targetElem.setAttribute(NameAttr, seqInfoList[i].seqId);
				targetElem.setAttribute(AliasAttr, seqInfoList[i].renameTo);
				targetElem.setAttribute(LengthAttr, seqInfoList[i].seqLength);
				targetElem.setAttribute(DescAttr, seqInfoList[i].descriptions);
				QFileInfo info(seqInfoList[i].seqFilePath);
				seqInfoList[i].seqFilePath=sourceDir.filePath(info.fileName());
				targetElem.setAttribute(PathAttr, revision_dir.relativeFilePath(seqInfoList[i].seqFilePath));
				targetElem.setAttribute(OffsetAttr, seqInfoList[i].fileOffset);
				targetsElem.appendChild(targetElem);
			}

			//FASTA�t�@�C���쐬�̏���
			seqInfoListTableModel.setSeqInfoList(seqInfoList);
            QString destFile=revision_dir.filePath(RevisionFastaFileTemp.arg(species).arg(revision));
			if (!createFasta.setFiles(destFile, seqInfoList)) {
				return;
			}
			createFasta.setOrder(true);

			//�_�C�A���O�̏���
			pdialog.setValue(0);
			pdialog.setLabelText(tr("Creating a FASTA file ..."));
			connect(&pdialog, SIGNAL(canceled()),
				this, SLOT(onCancelCreateFasta()));

            //�^�C�}�[�̏���
            connect(&timer, SIGNAL(timeout()),
				this, SLOT(onTimeOutCreateFasta()));

			//�����J�n
            timer.start();
            createFasta.start();
			pdialog.exec();
            break;

    }
}

void RevisionManager::onCancelFileCopy(void)
{

	fileCopy.setOrder(false);
	disconnect(&pdialog, SIGNAL(canceled()),
		this, SLOT(onCancelFileCopy()));

}


void RevisionManager::onTimeOutCreateFasta(void)
{
    CreateFasta::Process	process_status;
    quint64	prosessed_data;
    quint64	total_data;
    createFasta.getProcessStatus(process_status, prosessed_data, total_data);
    int progress;
    if(total_data!=0){
        progress = (int)((100*prosessed_data)/total_data);
    }
    else{
        progress = 0;
    }
    switch(process_status){

        case CreateFasta::processing:

			pdialog.setValue(progress);
            break;

        case CreateFasta::stopped:

			//�������~
			timer.stop();
			disconnect(&timer, SIGNAL(timeout()),
				this, SLOT(onTimeOutCreateFasta()));
			disconnect(&pdialog, SIGNAL(canceled()),
				this, SLOT(onCancelCreateFasta()));
			pdialog.cancel();
			break;

		case CreateFasta::failed:

			//�������~
			timer.stop();
			disconnect(&timer, SIGNAL(timeout()),
				this, SLOT(onTimeOutCreateFasta()));
			disconnect(&pdialog, SIGNAL(canceled()),
				this, SLOT(onCancelCreateFasta()));
			pdialog.cancel();

			QMessageBox::warning(this, "Warning", "Failed to create a FASTA file");

			break;

        case CreateFasta::finished:

			//�܂��͏������~
			timer.stop();
			disconnect(&timer, SIGNAL(timeout()),
				this, SLOT(onTimeOutCreateFasta()));
			disconnect(&pdialog, SIGNAL(canceled()),
				this, SLOT(onCancelCreateFasta()));
			pdialog.setValue(100);

            QString species = SpeciesComboBox->itemText(SpeciesComboBox->currentIndex());
            QString revision = RevisionLineEdit->text();
            //RevisionDir�Ɉړ�
            QDir revision_dir(QApplication::applicationDirPath());
            if(!revision_dir.exists(RevisionsDirName)){
                return;
            }
            if(!revision_dir.cd(RevisionsDirName)){
                return;
            }
            if(!revision_dir.exists(species)){
                return;
            }
            if(!revision_dir.cd(species)){
                return;
            }
            //revision�̃f�B���N�g���Ɉړ�
            if(!revision_dir.exists(revision)){
                return;
            }
            if(!revision_dir.cd(revision)){
                return;
            }
			//xml��fasta�t�@�C���̏���o�^
			QDomElement root=doc.documentElement();
			QDomElement fastaElem=doc.createElement(FastaFileTag);
			QString fastaFileName(RevisionFastaFileTemp.arg(species).arg(revision));
			fastaElem.setAttribute(PathAttr, fastaFileName);
			root.appendChild(fastaElem);

			//Revision�����i�[����XML�t�@�C�����쐬
			QFile file(revision_dir.filePath(RevisionFileName));
			if(!file.open(QIODevice::WriteOnly)){
				return;
			}

			//xml�t�@�C���ւ̏����o��
			file.write(doc.toByteArray());
			file.close();

			//�R���{�{�b�N�X�ɓo�^
			int i;
			bool revisionInserted=false;
			for(i=0; i<RevisionComboBox->count()-1; i++){
				if(revision<RevisionComboBox->itemText(i)){
					RevisionComboBox->insertItem(i, revision);
					RevisionComboBox->setCurrentIndex(i);
					revisionInserted=true;
					break;
				}
			}
			if(!revisionInserted){
				RevisionComboBox->insertItem(i, revision);
				RevisionComboBox->setCurrentIndex(i);
			}

			emit revisionCreated();
			pdialog.cancel();

            break;

    }
}

void RevisionManager::onCancelCreateFasta(void)
{

	createFasta.setOrder(false);
	disconnect(&pdialog, SIGNAL(canceled()),
		this, SLOT(onCancelCreateFasta()));

}


