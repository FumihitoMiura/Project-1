﻿function createConfigPane(targetTrack) {

    //config pane
    targetTrack.configPaneDiv = document.createElement("div");
    var titleDiv = document.createElement("div");
    titleDiv.innerHTML = "Configure BasecolorTrack";
    targetTrack.configPaneDiv.appendChild(titleDiv);
    
    hr = document.createElement("hr");
    targetTrack.configPaneDiv.appendChild(hr);

    //Color for A
    var colorSelectorDiv = document.createElement("div");
    targetTrack.configPaneDiv.appendChild(colorSelectorDiv);
    var colorSelectorTextSpan = document.createElement("span");
    colorSelectorTextSpan.innerHTML = "Color for A";
    colorSelectorDiv.appendChild(colorSelectorTextSpan);
    targetTrack.ColorForA = createColorSelector16();
    targetTrack.configPaneDiv.appendChild(targetTrack.ColorForA);
    targetTrack.ColorForA.owner = targetTrack;

    //Color for C
    var colorSelectorDiv = document.createElement("div");
    targetTrack.configPaneDiv.appendChild(colorSelectorDiv);
    var colorSelectorTextSpan = document.createElement("span");
    colorSelectorTextSpan.innerHTML = "Color for C";
    colorSelectorDiv.appendChild(colorSelectorTextSpan);
    targetTrack.ColorForC = createColorSelector16();
    targetTrack.configPaneDiv.appendChild(targetTrack.ColorForC);
    targetTrack.ColorForC.owner = targetTrack;
    
    //Color for G
    var colorSelectorDiv = document.createElement("div");
    targetTrack.configPaneDiv.appendChild(colorSelectorDiv);
    var colorSelectorTextSpan = document.createElement("span");
    colorSelectorTextSpan.innerHTML = "Color for G";
    colorSelectorDiv.appendChild(colorSelectorTextSpan);
    targetTrack.ColorForG = createColorSelector16();
    targetTrack.configPaneDiv.appendChild(targetTrack.ColorForG);
    targetTrack.ColorForG.owner = targetTrack;
    
    //Color for T
    var colorSelectorDiv = document.createElement("div");
    targetTrack.configPaneDiv.appendChild(colorSelectorDiv);
    var colorSelectorTextSpan = document.createElement("span");
    colorSelectorTextSpan.innerHTML = "Color for T";
    colorSelectorDiv.appendChild(colorSelectorTextSpan);
    targetTrack.ColorForT = createColorSelector16();
    targetTrack.configPaneDiv.appendChild(targetTrack.ColorForT);
    targetTrack.ColorForT.owner = targetTrack;
    
    //Color for N
    var colorSelectorDiv = document.createElement("div");
    targetTrack.configPaneDiv.appendChild(colorSelectorDiv);
    var colorSelectorTextSpan = document.createElement("span");
    colorSelectorTextSpan.innerHTML = "Color for N";
    colorSelectorDiv.appendChild(colorSelectorTextSpan);
    targetTrack.ColorForN = createColorSelector16();
    targetTrack.configPaneDiv.appendChild(targetTrack.ColorForN);
    targetTrack.ColorForN.owner = targetTrack;

    hr = document.createElement("hr");
    targetTrack.configPaneDiv.appendChild(hr);
    
    
    //row height設定用spinboxをつくる
    var rowHeightSpinboxDiv = document.createElement("div");
    var rowHeightSpinboxTextSpan = document.createElement("span");
    rowHeightSpinboxTextSpan.innerHTML = "Row height";
    rowHeightSpinboxDiv.appendChild(rowHeightSpinboxTextSpan);
    targetTrack.rowHeightSpinbox = createSpinBox(targetTrack, 20, 100, 20);
    targetTrack.rowHeightSpinbox.owner = targetTrack;
    rowHeightSpinboxDiv.appendChild(targetTrack.rowHeightSpinbox);
    targetTrack.configPaneDiv.appendChild(rowHeightSpinboxDiv);

    hr = document.createElement("hr");
    targetTrack.configPaneDiv.appendChild(hr);

   
   
    
    //create option_arguments object
    targetTrack.track_info.option_arguments = new Object();

    //Color for A
    targetTrack.ColorForA.onchange = function() {
        var mySelect = this.selectedIndex;

        if (mySelect == 0) {
            this.owner.track_info.option_arguments.color_for_a = escape("COLOR_FOR_A");
        }
        else {
            this.owner.track_info.option_arguments.color_for_a = escape(this[mySelect].value);
        }
        updateTrack(this.owner);
    };
    
    //Color for C
    targetTrack.ColorForC.onchange = function() {
        var mySelect = this.selectedIndex;

        if (mySelect == 0) {
            this.owner.track_info.option_arguments.color_for_c = escape("COLOR_FOR_C");
        }
        else {
            this.owner.track_info.option_arguments.color_for_c = escape(this[mySelect].value);
        }
        updateTrack(this.owner);
    };
    
    //Color for G
    targetTrack.ColorForG.onchange = function() {
        var mySelect = this.selectedIndex;

        if (mySelect == 0) {
            this.owner.track_info.option_arguments.color_for_g = escape("COLOR_FOR_G");
        }
        else {
            this.owner.track_info.option_arguments.color_for_g = escape(this[mySelect].value);
        }
        updateTrack(this.owner);
    };
    
    //Color for T
    targetTrack.ColorForT.onchange = function() {
        var mySelect = this.selectedIndex;

        if (mySelect == 0) {
            this.owner.track_info.option_arguments.color_for_t = escape("COLOR_FOR_T");
        }
        else {
            this.owner.track_info.option_arguments.color_for_t = escape(this[mySelect].value);
        }
        updateTrack(this.owner);
    };
    
    //Color for N
    targetTrack.ColorForN.onchange = function() {
        var mySelect = this.selectedIndex;

        if (mySelect == 0) {
            this.owner.track_info.option_arguments.color_for_n = escape("COLOR_FOR_N");
        }
        else {
            this.owner.track_info.option_arguments.color_for_n = escape(this[mySelect].value);
        }
        updateTrack(this.owner);
    };
    
    
    //spinbox for row height
    targetTrack.rowHeightSpinbox.onchange = function() {
        this.owner.track_info.option_arguments.row_height = this.value;
        updateTrack(this.owner);
    }; 

};

CreateTrack(
	{
		'track_name':'basecolor',
		'accept_species':{
			'species':'SPECIES',
			'revision':'REVISION'
		},
		'track_url':'TRACK_URL',
		'track_arguments':{
			'track_name':'basecolor'
		},
		'image':{
			'layer_arguments':{
				'track_layer':'image'
			}
		},
		'index':{
			'layer_arguments':{
				'track_layer':'index'
			}
		},
		'config_pane':'true'
		ANOTHER_PARAM
	}
);