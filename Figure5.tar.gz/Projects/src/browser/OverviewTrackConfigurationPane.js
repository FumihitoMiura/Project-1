﻿function createConfigPane(targetTrack) {

    //config pane
    targetTrack.configPaneDiv = document.createElement("div");
    var titleDiv = document.createElement("div");
    titleDiv.innerHTML = "Configure OverviewTrack";
    targetTrack.configPaneDiv.appendChild(titleDiv);
    
    hr = document.createElement("hr");
    targetTrack.configPaneDiv.appendChild(hr);

    //Foreground color
    var colorSelectorDiv = document.createElement("div");
    targetTrack.configPaneDiv.appendChild(colorSelectorDiv);
    var colorSelectorTextSpan = document.createElement("span");
    colorSelectorTextSpan.innerHTML = "Foreground color";
    colorSelectorDiv.appendChild(colorSelectorTextSpan);
    targetTrack.ForegroundColor = createColorSelector16();
    targetTrack.configPaneDiv.appendChild(targetTrack.ForegroundColor);
    targetTrack.ForegroundColor.owner = targetTrack;

    //Background color
    colorSelectorDiv = document.createElement("div");
    targetTrack.configPaneDiv.appendChild(colorSelectorDiv);
    colorSelectorTextSpan = document.createElement("span");
    colorSelectorTextSpan.innerHTML = "Background color";
    colorSelectorDiv.appendChild(colorSelectorTextSpan);
    targetTrack.BackgroundColor = createColorSelector16();
    targetTrack.configPaneDiv.appendChild(targetTrack.BackgroundColor);
    targetTrack.BackgroundColor.owner = targetTrack;

    //Color for display region
    colorSelectorDiv = document.createElement("div");
    targetTrack.configPaneDiv.appendChild(colorSelectorDiv);
    colorSelectorTextSpan = document.createElement("span");
    colorSelectorTextSpan.innerHTML = "Color for display region";
    colorSelectorDiv.appendChild(colorSelectorTextSpan);
    targetTrack.DispregionColor = createColorSelector16();
    targetTrack.configPaneDiv.appendChild(targetTrack.DispregionColor);
    targetTrack.DispregionColor.owner = targetTrack;   
    
    hr = document.createElement("hr");
    targetTrack.configPaneDiv.appendChild(hr);
    
    
    //row height設定用spinboxをつくる
    var rowHeightSpinboxDiv = document.createElement("div");
    var rowHeightSpinboxTextSpan = document.createElement("span");
    rowHeightSpinboxTextSpan.innerHTML = "Row height";
    rowHeightSpinboxDiv.appendChild(rowHeightSpinboxTextSpan);
    targetTrack.rowHeightSpinbox = createSpinBox(targetTrack, 20, 100, 20);
    targetTrack.rowHeightSpinbox.owner = targetTrack;
    rowHeightSpinboxDiv.appendChild(targetTrack.rowHeightSpinbox);
    targetTrack.configPaneDiv.appendChild(rowHeightSpinboxDiv);
    
    hr = document.createElement("hr");
    targetTrack.configPaneDiv.appendChild(hr);

   
   
    
    //create option_arguments object
    targetTrack.track_info.option_arguments = new Object();

    //Foreground color
    targetTrack.ForegroundColor.onchange = function() {
        var mySelect = this.selectedIndex;

        if (mySelect == 0) {
            this.owner.track_info.option_arguments.foreground_color = escape("FG_COLOR");
        }
        else {
            this.owner.track_info.option_arguments.foreground_color = escape(this[mySelect].value);
        }
        updateTrack(this.owner);
    };
    
    //Background color
    targetTrack.BackgroundColor.onchange = function() {
        var mySelect = this.selectedIndex;

        if (mySelect == 0) {
            this.owner.track_info.option_arguments.background_color = escape("BG_COLOR");
        }
        else {
            this.owner.track_info.option_arguments.background_color = escape(this[mySelect].value);
        }
        updateTrack(this.owner);
    };
    
    //Color for display region
    targetTrack.DispregionColor.onchange = function() {
        var mySelect = this.selectedIndex;

        if (mySelect == 0) {
            this.owner.track_info.option_arguments.dispregion_color = escape("MARK_COLOR");
        }
        else {
            this.owner.track_info.option_arguments.dispregion_color = escape(this[mySelect].value);
        }
        updateTrack(this.owner);
    };
    
    
    //spinbox for row height
    targetTrack.rowHeightSpinbox.onchange = function() {
        this.owner.track_info.option_arguments.row_height = this.value;
        updateTrack(this.owner);
    }; 
    
 };


CreateTrack(
	{
		'track_name':'overview',
		'accept_species':{
			'species':'SPECIES',
			'revision':'REVISION'
		},
		'track_url':'TRACK_URL',
		'track_arguments':{
			'track_name':'overview'
		},
		'image':{
			'layer_arguments':{
				'track_layer':'image'
			}
		},
		'index':{
			'layer_arguments':{
				'track_layer':'index'
			}
		},
		'config_pane':'true'
		ANOTHER_PARAM
	}
);