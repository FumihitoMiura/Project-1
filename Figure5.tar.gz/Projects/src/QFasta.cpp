#include "QFasta.h"

using namespace DesktopTrack;

QInputFastaFile::QInputFastaFile(QIODevice* device_):device(device_)
{
	if(device==0){
		isReady=false;
	}
	else{
		isReady=true;
	}
}

void QInputFastaFile::setDevice(QIODevice* device_){
	device=device_;
	seq_name="";
	if(device==0){
		isReady=false;
	}
	else{
		isReady=true;
	}
}

bool QInputFastaFile::getNextSeq(QString& seq_to, QString& seq_name_to, bool case_sensitive)
{
	if(!isReady){
		return false;
	}
	//static QString	seq_name;
	QString			buffer;
	bool			IsSeqObtained=false;
	bool			IsNameObtained=false;

	//2��ڈȍ~
	if(seq_name.size()>0){
		if(seq_name[0]=='>'){
			QStringList temp = seq_name.right(seq_name.size()-1).trimmed().split(QRegExp("\\s+"));
			seq_name_to=temp[0];
			IsNameObtained=true;
		}
	}

	while(!device->atEnd()){

		buffer=device->readLine();
		buffer=buffer.trimmed();

		if(buffer[0]=='>'){
			//�Ō�
			if(IsSeqObtained&&IsNameObtained){
				seq_name=buffer;
				return true;
			}
			//���߂�
			else if(!IsSeqObtained&&!IsNameObtained){
				QStringList temp = buffer.right(buffer.size()-1).trimmed().split(QRegExp("\\s+"));
				seq_name_to=temp[0];
				IsNameObtained=true;
			}
			//�z����擾����O�ɍĂі��O���A�A�A
			else if(!IsSeqObtained&&IsNameObtained){
				seq_name_to=buffer.right(buffer.size()-1);
			}
			//�z��͓���ꂽ���ǖ��O�͓����Ă��Ȃ�
			//fasta�t�@�C���Ƃ��Ă͂��肦�Ȃ�
			else{
				seq_to = "";
				seq_name_to = "";
				return false;
			}

		}
		else{
			if(IsSeqObtained){
				if(case_sensitive){
					seq_to.append(buffer.trimmed());
				}
				else{
					seq_to.append(buffer.toUpper().trimmed());
				}
			}
			else{
				if(case_sensitive){
					seq_to=buffer.trimmed();
				}
				else{
					seq_to=buffer.toUpper().trimmed();
				}
				IsSeqObtained=true;
			}

		}

	}

	if(IsSeqObtained&&IsNameObtained){
		return true;
	}

	seq_to = "";
	seq_name_to = "";
	return false;

}


QOutputOFastaFile::QOutputOFastaFile(QIODevice* device_):device(device_)
{
	if(device==0){
		isReady=false;
	}
	else{
		isReady=true;
	}
}


void  QOutputOFastaFile::setDevice(QIODevice* device_){
	device=device_;
	if(device==0){
		isReady=false;
	}
	else{
		isReady=true;
	}
}

bool QOutputOFastaFile::putNextSeq(const QString& seq, const QString& seq_name){
	
	if(!isReady){
		return false;
	}

	QTextStream out(device);
	out << ">" << seq_name << endl;

	int offset = 0;
	int line_length=60;

	while(offset+line_length<seq.size()){
		out << seq.mid(offset, line_length) << endl;
		offset+=line_length;
	}
	if(seq.size()%line_length==0){
		//���傤�ǖ��[���Ƃ炦���Ă���͂��Ȃ̂ŁA���̂܂ܔ�����
		return true;
	}
	else{
		out << seq.right(seq.size()%line_length) << endl;
		return true;
	}
}


bool QOutputOFastaFile::putNextSeq(const QByteArray& seq, const QString& seq_name){
	
	if(!isReady){
		return false;
	}

	QTextStream out(device);
	out << ">" << seq_name << endl;

	int offset = 0;
	int line_length=60;

	while(offset+line_length<seq.size()){
		out << seq.mid(offset, line_length) << endl;
		offset+=line_length;
	}
	if(seq.size()%line_length==0){
		//���傤�ǖ��[���Ƃ炦���Ă���͂��Ȃ̂ŁA���̂܂ܔ�����
		return true;
	}
	else{
		out << seq.right(seq.size()%line_length) << endl;
		return true;
	}

}



