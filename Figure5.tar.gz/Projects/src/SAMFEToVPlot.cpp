#include <QtCore>
#include <QtGui>
#include <vector>

#include "DesktopTrackCommon.h"
#include "BinSeq.h"
#include "VPlotFile.h"

using namespace DesktopTrack;

/*--------------------------------------------------------------------------------
Col		Field		Type Regexp/Range Brief description
----------------------------------------------------------------------------------
1		QNAME		String [!-?A-~]{1,254} Query template NAME
2		FLAG		Int [0,216-1] bitwise FLAG
3		RNAME		String \*|[!-()+-<>-~][!-~]* Reference sequence NAME
4		POS			Int [0,231-1] 1-based leftmost mapping POSition
5		MAPQ		Int [0,28-1] MAPping Quality
6		CIGAR		String \*|([0-9]+[MIDNSHPX=])+ CIGAR string
7		RNEXT		String \*|=|[!-()+-<>-~][!-~]* Ref. name of the mate/next read
8		PNEXT		Int [0,231-1] Position of the mate/next read
9		TLEN		Int [-231+1,231-1] observed Template LENgth
10		SEQ			String \*|[A-Za-z=.]+ segment SEQuence
11		QUAL		String [!-~]+ ASCII of Phred-scaled base QUALity+33
--------------------------------------------------------------------------------*/

struct BowtieSamLine {

	QString		QName;
	quint32		Flag;
	QString		RName;
	qint64		Pos;
	qint32		MapQ;
	QString		CIGAR;
	qint64		RNext;
	qint64		PNext;
	qint64		TLen;
	QString		Seq;
	QString		Qual;

	BowtieSamLine(void) :Flag(0), Pos(0), MapQ(0), RNext(0), PNext(0), TLen(0) {};

	BowtieSamLine(const BowtieSamLine& original):
		QName(original.QName),
		Flag(original.Flag),
		RName(original.RName),
		Pos(original.Pos),
		MapQ(original.MapQ),
		CIGAR(original.CIGAR),
		RNext(original.RNext),
		PNext(original.PNext),
		TLen(original.TLen),
		Seq(original.Seq),
		Qual(original.Qual){};

	BowtieSamLine(const QString& line)
	{
		QStringList cols = line.split(QString("\t"));
		QName = cols[0].split(QRegExp("\\s+"))[0];
		Flag = cols[1].toUInt();
		RName = cols[2];
		Pos = cols[3].toInt();
		MapQ = cols[4].toInt();
		CIGAR = cols[5];
		RNext = cols[6].toInt();
		PNext = cols[7].toInt();
		TLen = cols[9].size();
		Seq = cols[9];
		Qual = cols[10];
	}

	BowtieSamLine& operator=(const BowtieSamLine& original) {
		QName=original.QName;
		Flag=original.Flag;
		RName=original.RName;
		Pos=original.Pos;
		MapQ=original.MapQ;
		CIGAR=original.CIGAR;
		RNext=original.RNext;
		PNext=original.PNext;
		TLen=original.TLen;
		Seq=original.Seq;
		Qual=original.Qual;
		return *this;
	};

};

void showUsage(void) {
	cout << "Usage : SAMFEToVPlot [options]" << endl
		<< "  [Required Parameters]" << endl
		<< "   -species      [string]  : species name (Use with option \"-revision\")" << endl
		<< "   -revision     [string]  : revision name (Use with option \"-species\")" << endl
		<< "   -binseq       [string]  : binseq file path (Use mutually exclusively with \"-species\" and \"-revision\")" << endl
		<< "   -sam          [strings] : input sam files" << endl
		<< "   -vplot        [string]  : output vplot file name" << endl
		<< "   -min_size     [integer] : minimum fragment size, positive integer value, should be larger than 10." << endl
		<< "   -step_size    [integer] : size of each step, positive integer value, should be larger than 10." << endl
		<< "   -num_step     [integer] : number of steps, positive integer value, should be larger than 3." << endl
		<< "   -num_reads    [integer] : number of maximum mapped reads to create VPlot file, positive integer value, should be larger than 0." << endl;
}

QString species;
QString revision;
QString binseqPath;
QStringList samFileList;
QString vplotPath;
qint64 minSize = 11;
qint64 stepSize = 500;
qint64 totalNumStep = 1;
qint64 numReadsLimit = 0;

bool ProcessSpecies(void)
{
	//���s�t�@�C���̑��݂���f�B���N�g�����m�F
	QDir RevisionDir(QCoreApplication::applicationDirPath());
	//Revision�f�B���N�g��
	if (!RevisionDir.exists(RevisionsDirName)) {
		cerr << "Coundn't find revision directory.";
		return false;
	}
	if (!RevisionDir.cd(RevisionsDirName)) {
		cerr << "Coundn't find revision directory.";
		return false;
	}
	//species�̊m�F
	if (!RevisionDir.exists(species)) {
		cerr << "Couldn't find species \"" << species.toStdString() << "\".";
		return false;
	}
	if (!RevisionDir.cd(species)) {
		cerr << "Couldn't find species \"" << species.toStdString() << "\".";
		return false;
	}
	//revision�̊m�F
	if (!RevisionDir.exists(revision)) {
		cerr << "Couldn't find revision \"" << revision.toStdString() << "\".";
		return false;
	}
	if (!RevisionDir.cd(revision)) {
		cerr << "Couldn't find revision \"" << revision.toStdString() << "\".";
		return false;
	}
	//BinSeq�t�@�C���̊m�F
	QString binSeqFileName(BinSeqFileTemp.arg(species).arg(revision));
	if (RevisionDir.exists(binSeqFileName)) {
		binseqPath = RevisionDir.absoluteFilePath(binSeqFileName);
		return true;
	}
	return false;
}

bool ProcessArguments(int argc, char* argv[]) {

	int i = 1;
	while (i<argc) {
		QString option(argv[i]);
		if (option == QString("-species")) {
			i++;
			if (i == argc) {
				break;
			}
			species = argv[i];
		}
		else if (option == QString("-revision")) {
			i++;
			if (i == argc) {
				break;
			}
			revision = argv[i];
		}
		else if (option == QString("-binseq")) {
			i++;
			if (i == argc) {
				break;
			}
			binseqPath = argv[i];
		}
		else if (option == QString("-sam")) {
			i++;
			while (i < argc) {
				QString temp(argv[i]);
				if (temp[0] == QChar('-')) {
					i--;
					break;
				}
				samFileList.append(QString(argv[i]));
				i++;
			}
			
		}
		else if (option == QString("-vplot")) {
			i++;
			if (i == argc) {
				break;
			}
			vplotPath = argv[i];
		}
		else if (option == QString("-min_size")) {
			i++;
			if (i == argc) {
				break;
			}
			qint64 temp=QString(argv[i]).toInt();
			if (temp <= 10) {
				cerr << "Minimum fragment size should be larger than 10" << endl;
				return false;
			}
			minSize = temp;
		}
		else if (option == QString("-step_size")) {
			i++;
			if (i == argc) {
				break;
			}
			qint64 temp = QString(argv[i]).toInt();
			if (temp <= 0) {
				cerr << "Minimum step size should be larger than 1" << endl;
				return false;
			}
			stepSize = temp;
		}
		else if (option == QString("-num_step")) {
			i++;
			if (i == argc) {
				break;
			}
			qint64 temp = QString(argv[i]).toInt();
			if (temp < 1) {
				cerr << "Minimum number of steps should be larger than 0" << endl;
				return false;
			}
			totalNumStep = temp;
		}
		else if (option == QString("-num_reads")) {
			i++;
			if (i == argc) {
				break;
			}
			qint64 temp = QString(argv[i]).toInt();
			if (temp < 1) {
				cerr << "Number of reads should be larger than 0" << endl;
				return false;
			}
			numReadsLimit = temp;
		}
		else {
			cerr << "Error: Unknown option was specified:" << option.toStdString() << "." << endl << endl;
			return false;
		}
		i++;
	}
	return true;
}

bool ConfirmCriticalParameters(void) 
{
	if (binseqPath.size() == 0) {
		if (!ProcessSpecies()) {
			return false;
		}
	}
	if (samFileList.size() == 0) {
		cerr << "Error: One or more sam file should be specified." << endl;
		return false;
	}
	if (vplotPath.size() == 0) {
		cerr << "Error: Output file should be specified." << endl;
		return false;
	}
	return true;
}

int main(int argc, char* argv[]) {

	QCoreApplication app(argc, argv);

	//�I�v�V�������̎擾
	if (!ProcessArguments(argc, argv)) {
		cerr << "Error in processing arguments." << endl;
		showUsage();
		return 0;
	}
	//�K�v���̊m�F
	if (!ConfirmCriticalParameters()) {
		cerr << "Error in processing arguments." << endl;
		showUsage();
		return 0;
	}

	//BinSeq���������
	DesktopTrack::BinSeq::FileReader reader;
	if (!reader.setFile(binseqPath)) {
		return 0;
	}
	DesktopTrack::BinSeq::Header bHeader;
	bHeader = reader.getTrackConfig();

	//�o�̓t�@�C���̃I�[�v��
	QFile outFile(vplotPath);
	outFile.open(QIODevice::WriteOnly);
	if (!outFile.isOpen()) {
		cerr << "Couldn't open file \"" << vplotPath.toStdString() << "\"." << endl;
		return 0;
	}
	QFileInfo info(vplotPath);

	//VPlotFile�쐬�J�n
	DesktopTrack::VPlotFile::Header header;
	header.trackName = info.baseName();		//�t�@�C�����ƃg���b�N����v�̌���
	header.species = bHeader.species;
	header.revision = bHeader.revision;

	header.rowHeight = 10;
	header.fontSize = 10;
	header.fgColor = QColor::fromRgb(0, 0, 0);
	header.bgColor = QColor::fromRgb(255, 255, 255);
	header.anColor = QColor::fromRgb(255, 0, 0);
	header.minSize = minSize;
	header.sizeStep = stepSize;
	header.stepNum = totalNumStep;

	//�w�b�_�[�̉��o��
	QDataStream out(&outFile);
	header.putSerialized(out);

	//�z�񖈂ɃO���t�f�[�^���쐬����
	QList<DesktopTrack::BinSeq::Target> targetList = reader.getTargetList();
	std::vector<quint8> graphData;
	quint64 offset = 0;
	QMap<QString, quint64> offsetMap, sizeMap;
	for (int i = 0; i<targetList.size(); i++) {

		qint64 size = targetList[i].targetLength*(qint64)totalNumStep;
		QString targetName = targetList[i].targetName;
		if (offsetMap.contains(targetName) || sizeMap.contains(targetName)) {
			continue;
		}
		offsetMap[targetName] = offset;
		sizeMap[targetName] = size;
		offset += size;

	}
	graphData.resize(offset, 0);
	qint64 numReads = 0;

	for (int i = 0; i < samFileList.size(); i++) {

		QFile in;
		in.setFileName(samFileList[i]);
		in.open(QIODevice::ReadOnly);
		if (!in.isOpen()) {
			cerr << "Couldn't open input sam file \"" << samFileList[i].toStdString() << "\"." << endl
				 << "Exit program." << endl;
			return 0;
		}

		//bowtie pe�̏o�͂�������荞�ݔ��f����
		while (!in.atEnd()) {

			QString line = in.readLine().trimmed();
			if (line[0] == '@') {
				continue;
			}
			else {

				BowtieSamLine currData(line);

				/*--------------------------------------------------------------------------------
				Col		Field		Type Regexp/Range Brief description
				----------------------------------------------------------------------------------
				1		QNAME		String [!-?A-~]{1,254} Query template NAME
				2		FLAG		Int [0,216-1] bitwise FLAG
				3		RNAME		String \*|[!-()+-<>-~][!-~]* Reference sequence NAME
				4		POS			Int [0,231-1] 1-based leftmost mapping POSition
				5		MAPQ		Int [0,28-1] MAPping Quality
				6		CIGAR		String \*|([0-9]+[MIDNSHPX=])+ CIGAR string
				7		RNEXT		String \*|=|[!-()+-<>-~][!-~]* Ref. name of the mate/next read
				8		PNEXT		Int [0,231-1] Position of the mate/next read
				9		TLEN		Int [-231+1,231-1] observed Template LENgth
				10		SEQ			String \*|[A-Za-z=.]+ segment SEQuence
				11		QUAL		String [!-~]+ ASCII of Phred-scaled base QUALity+33
				--------------------------------------------------------------------------------*/

				qint64 numStep = 0;
				//�K��������
				while (numStep < totalNumStep) {
					qint64 stepMin = minSize + stepSize*numStep;
					qint64 stepMax = minSize + stepSize*(numStep + 1)-1;
					if ((currData.TLen >= stepMin)&&(currData.TLen <= stepMax)) {
						break;
					}
					numStep++;
				}
				//�K����������Ȃ��ꍇ���̃f�[�^�͖�������
				if (numStep == totalNumStep) {
					continue;
				}

				if (currData.Pos < 1) {
					continue;
				}
				if (currData.RName.size() == 0) {
					continue;
				}

				quint64 cutPos;
				//reverse complement frag
				if (currData.Flag & 0x0010) {
					//reverse complement
					cutPos = currData.Pos + currData.TLen-1;
				}
				else {
					//forward strand
					cutPos = currData.Pos;
				}

				qint64 dataPos = offsetMap[currData.RName] + (cutPos - 1)*totalNumStep + numStep;
				graphData[dataPos]++;
				numReads++;
				if (numReadsLimit != 0 && numReads > numReadsLimit) {
					break;	//while (!in.atEnd())
				}

			}

		}

		if (numReadsLimit != 0 && numReads > numReadsLimit) {
			break;	//for (int i = 0; i < samFileList.size(); i++)
		}

	}



	//�o�b�t�@�[����
	QByteArray data;
	QBuffer buffer;
	//�f�[�^�̏o��
	buffer.setBuffer(&data);
	buffer.open(QIODevice::WriteOnly);
	out.setDevice(&buffer);

	//�o�͊J�n
	quint8 maxValue = 0;
	QList<DesktopTrack::VPlotFile::Target> targetInfoList;
	for (int i = 0; i<targetList.size(); i++) {
		DesktopTrack::VPlotFile::Target temp;
		temp.targetName = targetList[i].targetName;
		temp.targetLength = targetList[i].targetLength;
		temp.dataOffset = outFile.pos() + buffer.pos();

		if (!offsetMap.contains(temp.targetName) || !sizeMap.contains(temp.targetName)) {
			continue;
		}
		qint64 offset = offsetMap[temp.targetName];
		qint64 size = sizeMap[temp.targetName];

		for (int j = offset; j<offset + size; j++) {
			if (maxValue<graphData[j]) {
				maxValue = graphData[j];
			}
			out << graphData[j];
			if (data.size()>DesktopTrack::BufferSizeMax) {
				buffer.close();
				outFile.write(data);
				data.clear();
				buffer.setBuffer(&data);
				buffer.open(QIODevice::WriteOnly);
				out.setDevice(&buffer);
			}
		}

		temp.dataSize = outFile.pos() + buffer.pos() - temp.dataOffset;
		targetInfoList.push_back(temp);
	}

	buffer.close();
	outFile.write(data);
	data.clear();
	buffer.setBuffer(&data);
	buffer.open(QIODevice::WriteOnly);
	out.setDevice(&buffer);


	//Target�̏����o�͂�header�Ƀf�[�^�̊i�[�ʒu�ƃT�C�Y��o�^
	header.targetListOffset = outFile.pos() + buffer.pos();
	header.targetListDataCount = targetInfoList.size();
	for (int i = 0; i<targetInfoList.size(); i++) {
		targetInfoList[i].putSerialized(out);
	}
	buffer.close();
	outFile.write(data);
	data.clear();
	header.targetListDataSize = outFile.pos() + buffer.pos() - header.targetListOffset;

	outFile.seek(0);
	out.setDevice(&outFile);
	header.putSerialized(out);


	return 0;

}
