#ifndef GENOMIC_VPLOT_DATA_H
#define GENOMIC_VPLOT_DATA_H

#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif

#include <cmath>
#include <iostream>

#include "DesktopTrackCommon.h"

namespace DesktopTrack{

	namespace VPlotFile{

		struct Header{

			quint32			magic;		//2346
			quint32			version;	//1

			//basic info
			QString			trackName;
			QString			species;
			QString			revision;

			//target info
			quint64			targetListOffset;		//
			quint64			targetListDataSize;
			quint64			targetListDataCount;

			//track configuration
			quint32			rowHeight;
			quint32			fontSize;
			QColor			fgColor;
			QColor			bgColor;
			QColor			anColor;

			quint32			minSize;
			quint32			sizeStep;
			quint32			stepNum;


			Header(void);
			Header(const Header& original);
			Header&	operator=(const Header& original);

			bool			isCorrectFile(void);
			void			getSerialized(QDataStream& in);
			void			putSerialized(QDataStream& out);
		};

		struct Target{
			QString		targetName;
			quint64		targetLength;
			quint64		dataOffset;
			quint64		dataSize;
			Target(void);
			Target(const QString& target_name, const quint32& target_length);
			Target(const Target& original);
			Target& operator=(const Target& original);
			void putSerialized(QDataStream& out);
			void getSerialized(QDataStream& in);
		};

		struct TargetLess{
			TargetLess(void);
			bool operator()(const Target& a, const Target& b);
		};


		class FileReader{
		protected:
			Header					header;
			QList<Target>			targetList;
			QMap<QString, int>		targetMap;
			QFile					file;

		public:
			FileReader(void);

			bool					setFile(const QString& filePath);
			bool					releaseFile(void);

			bool					unsetFile(void);

			const Header&			getBasicTrackInfo(void) const;

			const QList<Target>&	getTargetList(void) const;

			bool					targetContains(const QString& target_name);

			bool					setBasicTrackConf(const Header& conf);


			bool getData(
				const QString& target_name, 
				std::vector<std::vector<quint8> >& data_to);
											
			bool getData(
				const QString& target_name,
				const quint64& start,
				const quint64& end,
				std::vector<std::vector<quint8> >& data_to);


		};
	};
};

#endif
