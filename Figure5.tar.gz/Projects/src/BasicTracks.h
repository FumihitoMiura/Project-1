#include <QtCore>
#include <QtGui>
#include <QtSql>
#include <QtXml>

#ifndef BASIC_TRACK_H
#define BASIC_TRACK_H

#include "BasicTracksCGIParam.h"
#include "BinSeq.h"
#include "DesktopTrackCommon.h"

namespace DesktopTrack{

	class BasicTracks
	{
	public:
		
		BasicTracks(void);

		bool			printTrackLayer(void);

	private:
		QString							cgiUrl;
		bool							isCgi;
		BasicTracksCGIParam				CGIParam;
		BinSeq::FileReader				reader;

		BinSeq::Header					header;
		QColor	color_for_anti_a;
		QColor	color_for_anti_c;
		QColor	color_for_anti_g;
		QColor	color_for_anti_t;
		QColor	color_for_anti_n;

		int		base_color_track_row_height;

		bool	printTrackList(void);

		bool	printDescFile(void);

		bool	printImage(void);
		bool	printIndexImage(void);
		bool	printOperation(void);
		bool	printIndexOperation(void);

		//image
		bool	createOverviewImage(QImage& imageTo);
		bool	createRulerImage(QImage& imageTo);
		bool	createBaseColorImage(QImage& imageTo);
		void	createErrorImage(QImage& imageTo);

		//index image
		bool	createOverviewIndexImage(QImage& imageTo);
		bool	createRulerIndexImage(QImage& imageTo);
		bool	createBaseColorIndexImage(QImage& imageTo);
		void	createErrorIndexImage(QImage& imageTo);


		//operation


		//index operation

		void	paintBackGround(const QColor&,
								QImage* image);
		void	drawVarticalLine(	int h_pos,
									char base,
									int strand,	// 1 for forward, -1 for reverse
									QImage* image);
		void	drawBaseChar(	int h_start_pos,
								int width,
								char base,
								int strand,
								QFont font,
								QImage* image);
		void	drawGradLine(	const int& base_from,
								const int& base_to,
								const QColor& color,
								QImage* image);
		void	drawDisplayRegion(const int& base_from,
								  const int& base_to, 
								  const int& target_length,
								  const QColor& color, 
								  QImage* image);


	};

};

#endif

