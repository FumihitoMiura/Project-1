#ifndef COLOR_INDICATOR_WIDGET
#define COLOR_INDICATOR_WIDGET

#include <QtCore>
#if QT_VERSION >= 0x050000
#include <QtWidgets>
#else
#include <QtGui>
#endif

class ColorIndicatorWidget : public QWidget
{
	Q_OBJECT
public:
	ColorIndicatorWidget(QWidget* parent=0);

	void	SetColor(const QColor& color);
	const	QString&	GetColorName(void) const;
	const	QColor&		GetColor(void) const;

private:
	QColor	fgColor;	//����
	QColor	bgColor;	//�w�i
	QString	fgColorName;
	QString bgColorName;
	void	paintEvent(QPaintEvent *events);

};


#endif

