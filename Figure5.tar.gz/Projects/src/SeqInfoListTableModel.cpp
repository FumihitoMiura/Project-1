#include "SeqInfoListTableModel.h"

using namespace DesktopTrack;

/*-------------------------------------------------------------------------------------------------
	SeqInfoListTableModel
-------------------------------------------------------------------------------------------------*/

SeqInfoListTableModel::
SeqInfoListTableModel(QObject* parent)
:editable(true), QAbstractTableModel(parent){}

void SeqInfoListTableModel::
setSeqInfoList(const SeqInfoList& list)
{
	emit layoutAboutToBeChanged();
	seqInfoList = list;
	emit layoutChanged();
}

void SeqInfoListTableModel::setEditable(bool to)
{
	editable = to;
}

int SeqInfoListTableModel::
rowCount(const QModelIndex& /*parent*/) const
{
	return seqInfoList.size();
}

int SeqInfoListTableModel::
columnCount(const QModelIndex& /*index*/) const
{
	return 6;		//seq_name, rename_to, descriptions, length, offset, file_path
}

QVariant SeqInfoListTableModel::
data(const QModelIndex& index, int role) const
{
	//�C���f�b�N�X�͈̔͊m�F
	if(!index.isValid()){
		return QVariant();
	}
	if(index.row()>=seqInfoList.size()){
		return QVariant();
	}
	if(role==Qt::DisplayRole){
		if(index.column()==0){
			return seqInfoList[index.row()].seqId;
		}
		else if(index.column()==1){
			return seqInfoList[index.row()].renameTo;
		}
		else if(index.column()==2){
			return seqInfoList[index.row()].seqFilePath;
		}
		else if(index.column()==3){
			return seqInfoList[index.row()].seqLength;
		}
		else if(index.column()==4){
			return seqInfoList[index.row()].fileOffset;
		}
		else if(index.column()==5){
			return seqInfoList[index.row()].descriptions;
		}
		else{
			return QVariant();
		}
	}
	else{
		return QVariant();
	}
}

QVariant SeqInfoListTableModel::
headerData(	int section, Qt::Orientation orientation, int role) const
{
	if(role!=Qt::DisplayRole){
		return QVariant();
	}
	if(orientation==Qt::Vertical){
		return QString::number(section+1);
	}
	else{
		switch(section){
			case 0:
				return QString::fromUtf8("Sequence ID");
			case 1:
				return QString::fromUtf8("Rename To");
			case 2:
				return QString::fromUtf8("File Path");
			case 3:
				return QString::fromUtf8("Length");
			case 4:
				return QString::fromUtf8("File Offset");
			case 5:
				return QString::fromUtf8("Descriptions");
			default:
				return QVariant();
		}
	}
}

Qt::ItemFlags SeqInfoListTableModel::
flags(const QModelIndex& index) const
{
	if(!index.isValid()){
		return Qt::ItemIsEnabled;
	}
	if(index.column()==1){
		if(editable){
			return QAbstractItemModel::flags(index) | Qt::ItemIsEditable;
		}
		else{
			return QAbstractItemModel::flags(index);
		}
	}
	else{
		return QAbstractItemModel::flags(index);
	}
}

bool SeqInfoListTableModel::
setData(const QModelIndex& index, const QVariant& value, int role)
{
	if(!index.isValid()){
		return false;
	}
	if(role!=Qt::EditRole){
		return false;
	}
	if(index.row()>=seqInfoList.size()){
		return false;
	}
	switch(index.column()){
		case 1:
			seqInfoList[index.row()].renameTo=value.toString();
			break;
		default:
			return false;
	}
	emit dataChanged(index, index);
	return true;
}

const SeqInfoList& SeqInfoListTableModel::getSeqInfoList(void) const
{
	return seqInfoList;
}

