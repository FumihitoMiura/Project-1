#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main(int argc, char* argv[]){

	if(argc!=3){
		cerr << "Usage:" << argv[0] << "Input[fastq] Output[fastq]" << endl;
		return 0;
	}

	ifstream in;
	in.open(argv[1]);
	if(!in.is_open()){
		cerr << "Couldn't open file \"" << argv[1] << "\"." << endl;
		return 0;
	}
	ofstream out;
	out.open(argv[2]);
	if(!out.is_open()){
		cerr << "Couldn't open file \"" << argv[2] << "\"." << endl;
		return 0;
	}

	int line_number=0;
	string line;
	while(getline(in, line)){

		line_number++;

		switch(line_number%4){
			case 1:
				line[0]='>';
				out << line << endl;
				break;
			case 2:
				out << line << endl;
				break;
			case 3:
				//nothing to do
				break;
			case 0:
				//nothing to do
				break;

		}


	}
	
	return 0;

}



