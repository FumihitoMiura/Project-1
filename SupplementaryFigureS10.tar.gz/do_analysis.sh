#if the blast is correctly installed you can use makeblastdb command
echo "Making blast db"
makeblastdb -in db.fasta -dbtype nucl 1> log.txt 2> error_log.txt
#preparation of programs
echo "Compiling programs"
g++ -o fastq2fasta fastq2fasta.cpp
g++ -o summarize_blast summarize_blast.cpp

#convert illumina output to fastq file
echo "Downloading fastq file from SRA"
fastq-dump SRR6770856
./fastq2fasta SRR6770856.fastq SRR6770856.fasta

#map the reads
echo "Mapping"
blastn -db db.fasta -num_threads 12 -outfmt 6 -num_alignments 1 -query SRR6770856.fasta -out SRR6770856.m8 1>> log.txt 2>> error_log.txt

#summarize the mapping result
echo "Summarizing"
./summarize_blast SRR6770856.m8 SRR6770856.result.txt
 



