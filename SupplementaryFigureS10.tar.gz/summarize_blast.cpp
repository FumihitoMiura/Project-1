#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>

using namespace std;

void fill_vector(vector<int>& target, int begin, int end){

	int size=target.size();
	if(begin>=end){

		int temp=begin;
		begin=end;
		end=temp;

	}

	if(begin<1){

		begin=1;

	}

	if(end>size){
		return;
	}

	for(int i=begin-1; i<end; i++){
		target[i]++;
	}

}

void export_vector(vector<int>& target, ofstream& out){

	for(int i=0; i<target.size(); i++){
		out << target[i] << '\t';
	}
	out << endl;

}


int main(int argc, char* argv[]){

	if(argc!=3){
		cerr	<< "Error: Incorrect usage." << endl
			<< "Usage: " << argv[0] << " Input [in blast m8 format] Output [in text format]" << endl;
		return 0;
	}

	ifstream in;
	in.open(argv[1]);
	if(!in.is_open()){
		cerr	<< "Couldn't open input file \"" << argv[1] << "\"." << endl;
		return 0;
	}
	ofstream out;
	out.open(argv[2]);
	if(!out.is_open()){
		cerr	<< "Couldn't open output file\"" << argv[2] << "\"." << endl;
		return 0;
	}
 
	vector<int> READ_1(102, 0), READ_2(102, 0), READ_3(102, 0), READ_4(102, 0), READ_5(102, 0);
	vector<int> RDN18_1(100, 0), RDN18_2(100, 0), RDN18_3(100, 0), RDN18_4(100, 0), RDN18_5(100, 0);

	string line;
	while(getline(in, line)){

		istringstream ist(line);
		string col;
		vector<string> cols;

		while(getline(ist, col, '\t')){
			cols.push_back(col);
		}
		if(cols.size()!=12){
			continue;
		}

		if(cols[1]=="RDN18-1#1"){

			int query_begin=atoi(cols[6].c_str());
			int query_end=atoi(cols[7].c_str());
			int sbjct_begin=atoi(cols[9].c_str());
			int sbjct_end=atoi(cols[8].c_str());
			fill_vector(READ_1, query_begin, query_end);
			fill_vector(RDN18_1, sbjct_begin, sbjct_end);

		}
		else if(cols[1]=="RDN18-1#2"){

                        int query_begin=atoi(cols[6].c_str());
                        int query_end=atoi(cols[7].c_str());
                        int sbjct_begin=atoi(cols[9].c_str());
                        int sbjct_end=atoi(cols[8].c_str());
                        fill_vector(READ_2, query_begin, query_end);
                        fill_vector(RDN18_2, sbjct_begin, sbjct_end);

                }
		else if(cols[1]=="RDN18-1#3"){

                        int query_begin=atoi(cols[6].c_str());
                        int query_end=atoi(cols[7].c_str());
                        int sbjct_begin=atoi(cols[9].c_str());
                        int sbjct_end=atoi(cols[8].c_str());
                        fill_vector(READ_3, query_begin, query_end);
                        fill_vector(RDN18_3, sbjct_begin, sbjct_end);

                }
		else if(cols[1]=="RDN18-1#4"){

                        int query_begin=atoi(cols[6].c_str());
                        int query_end=atoi(cols[7].c_str());
                        int sbjct_begin=atoi(cols[9].c_str());
                        int sbjct_end=atoi(cols[8].c_str());
                        fill_vector(READ_4, query_begin, query_end);
                        fill_vector(RDN18_4, sbjct_begin, sbjct_end);

                }
		else if(cols[1]=="RDN18-1#5"){

                        int query_begin=atoi(cols[6].c_str());
                        int query_end=atoi(cols[7].c_str());
                        int sbjct_begin=atoi(cols[9].c_str());
                        int sbjct_end=atoi(cols[8].c_str());
                        fill_vector(READ_5, query_begin, query_end);
                        fill_vector(RDN18_5, sbjct_begin, sbjct_end);

                }
		else{
			cout << "Unknown:" << cols[1] << endl;
		}


	}

	out << "Query_1\t";
	export_vector(READ_1, out);
	out << "Query_2\t";
        export_vector(READ_2, out);
	out << "Query_3\t";
        export_vector(READ_3, out);
	out << "Query_4\t";
        export_vector(READ_4, out);
	out << "Query_5\t";
        export_vector(READ_5, out);

	out << "Subject_1\t";
        export_vector(RDN18_1, out);
	out << "Subject_2\t";
        export_vector(RDN18_2, out);
	out << "Subject_3\t";
        export_vector(RDN18_3, out);
	out << "Subject_4\t";
        export_vector(RDN18_4, out);
	out << "Subject_5\t";
        export_vector(RDN18_5, out);

	return 0;


}




