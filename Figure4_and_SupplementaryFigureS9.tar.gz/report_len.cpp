#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <cstdlib>

using namespace std;

int main(int argc, char* argv[]){

	if(argc!=4){
		cerr << "Usage:" << argv[0] << " MaxReadLength[integer]  Input[fastqc] Output[txt]" << endl;
		return 0;
	}

	int max_len=atoi(argv[1]);
	if(max_len<2){
		cerr << "Length should be larger than 1" << endl;
		return 0;
	}

	ifstream in;
	in.open(argv[2]);
	if(!in.is_open()){
		cerr << "Couldn't open file \"" << argv[2] << "\"." << endl;
		return 0;
	}
	ofstream out;
	out.open(argv[3]);
	if(!out.is_open()){
		cerr << "Couldn't open file \"" << argv[3] << "\"." << endl;
		return 0;
	}

	int line_number=0;
	string line;
	map<int, int> count_map;
	vector<int> a(max_len, 0), c(max_len, 0), g(max_len, 0), t(max_len, 0);
	while(getline(in, line)){

		line_number++;
		if(line_number%4!=2){
			continue;
		}

		int len=line.size();
		count_map[len]++;
		
		int limit=len>max_len?max_len:len;

		for(int i=0; i<limit; i++){

			if(line[i]=='A'){
				a[i]++;
			}
			else if(line[i]=='C'){
				c[i]++;
			}
			else if(line[i]=='G'){
				g[i]++;
			}
			else if(line[i]=='T'){
				t[i]++;
			}
		}
	}
	
	out << "length\tcount" << endl;
	for(map<int, int>::iterator itr=count_map.begin(); itr!=count_map.end(); itr++){
		out << itr->first << "\t" << itr->second << endl;
	}
	out << endl;

	out << "pos\ta\tc\tg\tt" << endl;
	for(int i=0; i< max_len; i++){
		out << i+1 << '\t' << a[i] << '\t' << c[i] << '\t'<< g[i] << '\t'<< t[i] << endl;
	}


	return 0;

}



