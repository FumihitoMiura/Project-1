#compile the program
echo "Compiling program"
g++ -o report_len report_len.cpp

#analyze the fastq files
echo "Downloading SRR6770854 (N100-TCS)"
fastq-dump SRR6770854
echo "Calculating read length and nucleotide composition for N100-TCS"
./report_len 150 SRR6770854.fastq N100-TCS.txt
echo "Downloading SRR6770855 (N100-phosphoramidite)"
fastq-dump SRR6770855
echo "Calculating read length and nucleotide composition for N100-phosphoramidite"
./report_len 150 N80-phosphoramidite.fastq N80-phosphoramidite.txt
echo "Finished"
